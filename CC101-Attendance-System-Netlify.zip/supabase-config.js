window.CC101_SUPABASE_CONFIG = {
  url: "https://jwuqjgnoeuutldwjusyp.supabase.co",
  anonKey: "sb_publishable_Awb2sIYXlEOisA5eLS3KwA_0sw14twx"
};
