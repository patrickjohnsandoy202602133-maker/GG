"use strict";

(() => {
  const courses = [
    { group: "COMPUTING AND TECHNOLOGY", name: "Bachelor of Science in Information Technology (BSIT)" },
    { group: "COMPUTING AND TECHNOLOGY", name: "Bachelor of Science in Computer Science (BSCS)" },
    { group: "COMPUTING AND TECHNOLOGY", name: "Bachelor of Science in Information Systems (BSIS)" },
    { group: "BUSINESS", name: "Bachelor of Science in Business Administration (BSBA)" },
    { group: "BUSINESS", name: "Bachelor of Science in Accountancy (BSA)" },
    { group: "BUSINESS", name: "Bachelor of Science in Management Accounting (BSMA)" },
    { group: "BUSINESS", name: "Bachelor of Science in Entrepreneurship (BS Entrep)" },
    { group: "EDUCATION", name: "Bachelor of Elementary Education (BEEd)" },
    { group: "EDUCATION", name: "Bachelor of Secondary Education (BSEd)" },
    { group: "EDUCATION", name: "Bachelor of Early Childhood Education (BECEd)" },
    { group: "ENGINEERING", name: "Bachelor of Science in Civil Engineering (BSCE)" },
    { group: "ENGINEERING", name: "Bachelor of Science in Mechanical Engineering (BSME)" },
    { group: "ENGINEERING", name: "Bachelor of Science in Electrical Engineering (BSEE)" },
    { group: "ENGINEERING", name: "Bachelor of Science in Electronics Engineering (BSECE)" },
    { group: "HEALTH SCIENCES", name: "Bachelor of Science in Nursing (BSN)" },
    { group: "HEALTH SCIENCES", name: "Bachelor of Science in Pharmacy (BSPharm)" },
    { group: "HEALTH SCIENCES", name: "Bachelor of Science in Medical Technology (BSMT)" },
    { group: "HOSPITALITY AND TOURISM", name: "Bachelor of Science in Hospitality Management (BSHM)" },
    { group: "HOSPITALITY AND TOURISM", name: "Bachelor of Science in Tourism Management (BSTM)" },
    { group: "ARTS AND SOCIAL SCIENCES", name: "Bachelor of Arts in Communication (BA Communication)" },
    { group: "ARTS AND SOCIAL SCIENCES", name: "Bachelor of Arts in Psychology (BA Psychology)" },
    { group: "ARTS AND SOCIAL SCIENCES", name: "Bachelor of Science in Psychology (BS Psychology)" }
  ];
  const pageNames = {
    dashboard: "Dashboard",
    students: "Students",
    attendance: "Attendance",
    records: "Records",
    "qr-attendance": "QR Attendance",
    events: "Events",
    fines: "Fines",
    settings: "Settings"
  };
  const LEGACY_STORAGE_KEY = "student-attendance-management-v1";
  const today = toLocalDateInputValue(new Date());
  const state = { students: [], records: [], schedule: emptySchedule(), events: [], fines: [] };
  let supabaseClient = null;
  let realtimeChannel = null;
  let signedInUser = null;
  let verifyingUserId = null;
  let refreshInProgress = false;
  let refreshQueued = false;
  let fineHistoryStudentId = null;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const numberAnimations = new WeakMap();
  let donutAnimation = 0;
  let donutProgress = 0;
  let toastTimer;

  const elements = {
    pages: document.querySelectorAll(".page"),
    navLinks: document.querySelectorAll(".nav-link"),
    sidebar: document.getElementById("sidebar"),
    mobileScrim: document.getElementById("mobileScrim"),
    menuToggle: document.getElementById("menuToggle"),
    dialog: document.getElementById("studentDialog"),
    form: document.getElementById("studentForm"),
    toast: document.getElementById("toast")
  };

  function toLocalDateInputValue(date) {
    const offsetDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return offsetDate.toISOString().slice(0, 10);
  }

  function emptySchedule() {
    return {
      signInStart: null,
      signInEnd: null,
      signOutStart: null,
      signOutEnd: null,
      afternoonSignInStart: null,
      afternoonSignInEnd: null,
      afternoonSignOutStart: null,
      afternoonSignOutEnd: null
    };
  }

  function normalizeScheduleTime(value) {
    if (typeof value === "string") {
      const legacyMatch = value.match(/^([01]\d|2[0-3]):([0-5]\d)(?::[0-5]\d(?:\.\d+)?)?$/);
      if (!legacyMatch) return null;
      const hour24 = Number(legacyMatch[1]);
      return {
        hour: String(hour24 % 12 || 12).padStart(2, "0"),
        minute: legacyMatch[2],
        period: hour24 < 12 ? "AM" : "PM"
      };
    }
    if (!value || typeof value !== "object") return null;
    const hour = String(value.hour || "").padStart(2, "0");
    const minute = String(value.minute || "").padStart(2, "0");
    if (!/^(0[1-9]|1[0-2])$/.test(hour) || !/^(0\d|[1-5]\d)$/.test(minute) ||
      (value.period !== "AM" && value.period !== "PM")) return null;
    return { hour, minute, period: value.period };
  }

  function normalizeSchedule(schedule) {
    const normalized = emptySchedule();
    if (!schedule || typeof schedule !== "object") return normalized;
    Object.keys(normalized).forEach(key => {
      normalized[key] = normalizeScheduleTime(schedule[key]);
    });
    return normalized;
  }

  function scheduleTimeForDatabase(value) {
    const minutes = timeInMinutes(value);
    if (minutes === null) return null;
    return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}:00`;
  }

  function scheduleFromDatabase(row) {
    return normalizeSchedule(row ? {
      signInStart: row.sign_in_start,
      signInEnd: row.sign_in_end,
      signOutStart: row.sign_out_start,
      signOutEnd: row.sign_out_end,
      afternoonSignInStart: row.afternoon_sign_in_start,
      afternoonSignInEnd: row.afternoon_sign_in_end,
      afternoonSignOutStart: row.afternoon_sign_out_start,
      afternoonSignOutEnd: row.afternoon_sign_out_end
    } : null);
  }

  function mapStudentFromDatabase(row) {
    return {
      id: row.student_id,
      name: row.full_name,
      course: row.course,
      yearLevel: row.year_level,
      section: row.section,
      createdAt: row.created_at
    };
  }

  function mapEventFromDatabase(row) {
    return {
      id: row.id,
      name: row.name,
      date: row.event_date,
      location: row.location,
      enableFines: row.enable_fines,
      active: row.is_active,
      periods: {
        morningSignIn: [row.morning_sign_in_start, row.morning_sign_in_end],
        morningSignOut: [row.morning_sign_out_start, row.morning_sign_out_end],
        afternoonSignIn: [row.afternoon_sign_in_start, row.afternoon_sign_in_end],
        afternoonSignOut: [row.afternoon_sign_out_start, row.afternoon_sign_out_end]
      }
    };
  }

  function readLegacyLocalData() {
    try {
      const saved = localStorage.getItem(LEGACY_STORAGE_KEY);
      if (!saved) return null;
      const parsed = JSON.parse(saved);
      if (!parsed || !Array.isArray(parsed.students) || !Array.isArray(parsed.records)) {
        throw new Error("The previous local attendance data has an unexpected format.");
      }
      return parsed;
    } catch (error) {
      console.error("Could not read previous local attendance data for import.", error);
      return null;
    }
  }

  function legacyTimeToTimestamp(dateValue, timeValue) {
    if (!timeValue) return null;
    const timeMatch = /^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$/.exec(timeValue);
    const dateMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateValue);
    if (!timeMatch || !dateMatch) return null;
    const date = new Date(
      Number(dateMatch[1]),
      Number(dateMatch[2]) - 1,
      Number(dateMatch[3]),
      Number(timeMatch[1]),
      Number(timeMatch[2]),
      Number(timeMatch[3] || 0)
    );
    return date.toISOString();
  }

  function mapRecordFromDatabase(row) {
    return {
      studentId: row.student_id,
      name: row.full_name,
      course: row.course,
      yearLevel: row.year_level,
      section: row.section,
      date: row.attendance_date,
      timeIn: row.time_in ? formatDatabaseTimestamp(row.time_in) : "",
      timeOut: row.time_out ? formatDatabaseTimestamp(row.time_out) : "",
      timeInRaw: row.time_in,
      timeOutRaw: row.time_out,
      status: row.status,
      createdAt: row.created_at
    };
  }

  function formatDatabaseTimestamp(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime())
      ? value
      : date.toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit", hour12: true });
  }

  function databaseStudentPayload(student) {
    return {
      student_id: student.id,
      full_name: student.name,
      course: student.course,
      year_level: student.yearLevel,
      section: student.section
    };
  }

  async function reloadRemoteData() {
    if (!supabaseClient || !signedInUser) return;
    if (refreshInProgress) {
      refreshQueued = true;
      return;
    }
    refreshInProgress = true;
    try {
      const [studentsResult, recordsResult, settingsResult, eventsResult, finesResult] = await Promise.all([
        supabaseClient.from("students").select("*").order("full_name"),
        supabaseClient.from("attendance").select("*").order("attendance_date", { ascending: false }),
        supabaseClient.from("attendance_settings").select("*").eq("id", 1).maybeSingle(),
        supabaseClient.from("events").select("*").order("event_date", { ascending: false }),
        supabaseClient.from("fines").select("*").order("event_date", { ascending: false })
      ]);
      const failed = [studentsResult, recordsResult, settingsResult, eventsResult, finesResult].find(result => result.error);
      if (failed) throw failed.error;
      if (!signedInUser) return;
      state.students = studentsResult.data.map(mapStudentFromDatabase);
      state.records = recordsResult.data.map(mapRecordFromDatabase);
      state.schedule = scheduleFromDatabase(settingsResult.data);
      state.events = eventsResult.data.map(mapEventFromDatabase);
      state.fines = finesResult.data;
      const legacyData = readLegacyLocalData();
      document.getElementById("legacyImportNotice").hidden =
        state.students.length > 0 || !legacyData || legacyData.students.length === 0;
      render();
      renderEvents();
      renderFines();
      if (document.getElementById("fineHistoryDialog").open) renderFineHistory();
      renderScheduleSummary();
      const activePage = document.querySelector(".page.active");
      if (activePage && activePage.id === "page-settings" &&
        !document.getElementById("scheduleForm").contains(document.activeElement)) {
        renderScheduleForm();
      }
      document.getElementById("syncStatus").textContent = "Live sync connected";
    } catch (error) {
      console.error("Could not load shared attendance data from Supabase.", error);
      document.getElementById("syncStatus").textContent = "Sync error";
      showToast(`Could not load shared data: ${error.message}`, true);
    } finally {
      refreshInProgress = false;
      if (refreshQueued) {
        refreshQueued = false;
        reloadRemoteData();
      }
    }
  }

  function subscribeToRemoteChanges() {
    if (!supabaseClient || !signedInUser) return;
    if (realtimeChannel) supabaseClient.removeChannel(realtimeChannel);
    realtimeChannel = supabaseClient.channel("cc101-shared-attendance")
      .on("postgres_changes", { event: "*", schema: "public", table: "students" }, reloadRemoteData)
      .on("postgres_changes", { event: "*", schema: "public", table: "attendance" }, reloadRemoteData)
      .on("postgres_changes", { event: "*", schema: "public", table: "attendance_settings" }, reloadRemoteData)
      .on("postgres_changes", { event: "*", schema: "public", table: "events" }, reloadRemoteData)
      .on("postgres_changes", { event: "*", schema: "public", table: "event_attendance" }, reloadRemoteData)
      .on("postgres_changes", { event: "*", schema: "public", table: "fines" }, reloadRemoteData)
      .subscribe(status => {
        document.getElementById("syncStatus").textContent =
          status === "SUBSCRIBED" ? "Live sync connected" :
            status === "CHANNEL_ERROR" || status === "TIMED_OUT" ? "Realtime reconnecting…" : "Connecting…";
      });
  }

  async function importLegacyData() {
    const legacyData = readLegacyLocalData();
    if (!legacyData || legacyData.students.length === 0) return;
    const button = document.getElementById("importLegacyData");
    button.disabled = true;
    button.textContent = "Importing…";
    let importedStudents = 0;
    let importedRecords = 0;
    try {
      for (const legacyStudent of legacyData.students) {
        const student = {
          id: String(legacyStudent.id || "").trim(),
          name: String(legacyStudent.name || "").trim(),
          course: String(legacyStudent.course || "").trim(),
          yearLevel: normalizeYearLevel(legacyStudent.yearLevel, legacyStudent.section),
          section: sectionLetter(legacyStudent.section)
        };
        if (!student.id || !student.name || !student.course || !student.yearLevel || !student.section) continue;
        const { data: existing, error: lookupError } = await supabaseClient.from("students")
          .select("student_id").eq("student_id", student.id).maybeSingle();
        if (lookupError) throw lookupError;
        if (existing) continue;
        const { error } = await supabaseClient.from("students").insert(databaseStudentPayload(student));
        if (error && error.code !== "23505") throw error;
        if (!error) importedStudents += 1;
      }
      for (const legacyRecord of legacyData.records) {
        const studentId = String(legacyRecord.studentId || "").trim();
        const attendanceDate = String(legacyRecord.date || "");
        if (!studentId || !attendanceDate) continue;
        const { data: existing, error: lookupError } = await supabaseClient.from("attendance")
          .select("id").eq("student_id", studentId).eq("attendance_date", attendanceDate).maybeSingle();
        if (lookupError) throw lookupError;
        if (existing) continue;
        const student = legacyData.students.find(item => item.id === legacyRecord.studentId);
        const payload = {
          student_id: studentId,
          attendance_date: attendanceDate,
          time_in: legacyTimeToTimestamp(attendanceDate, legacyRecord.timeIn),
          time_out: legacyTimeToTimestamp(attendanceDate, legacyRecord.timeOut),
          status: ["Present", "Late", "Absent"].includes(legacyRecord.status) ? legacyRecord.status : "Absent",
          full_name: legacyRecord.name || (student && student.name) || "Previous student",
          course: legacyRecord.course || (student && student.course) || "Not recorded",
          year_level: normalizeYearLevel(legacyRecord.yearLevel || (student && student.yearLevel), legacyRecord.section || (student && student.section)) || "1st Year",
          section: sectionLetter(legacyRecord.section || (student && student.section)) || "A"
        };
        const { error } = await supabaseClient.from("attendance").insert(payload);
        if (error && error.code !== "23505") throw error;
        if (!error) importedRecords += 1;
      }
      if (state.schedule.signInStart === null && legacyData.schedule) {
        const schedule = normalizeSchedule(legacyData.schedule);
        if (schedule.signInStart && schedule.signInEnd) {
          const { error } = await supabaseClient.from("attendance_settings").upsert({
            id: 1,
            sign_in_start: scheduleTimeForDatabase(schedule.signInStart),
            sign_in_end: scheduleTimeForDatabase(schedule.signInEnd),
            sign_out_start: scheduleTimeForDatabase(schedule.signOutStart),
            sign_out_end: scheduleTimeForDatabase(schedule.signOutEnd),
            afternoon_sign_in_start: scheduleTimeForDatabase(schedule.afternoonSignInStart),
            afternoon_sign_in_end: scheduleTimeForDatabase(schedule.afternoonSignInEnd),
            afternoon_sign_out_start: scheduleTimeForDatabase(schedule.afternoonSignOutStart),
            afternoon_sign_out_end: scheduleTimeForDatabase(schedule.afternoonSignOutEnd)
          }, { onConflict: "id" });
          if (error) throw error;
        }
      }
      await reloadRemoteData();
      showToast(`Imported ${importedStudents} students and ${importedRecords} attendance records.`);
    } catch (error) {
      console.error("Could not fully import previous local attendance data.", error);
      showToast(`Import stopped. Completed rows are safe to retry: ${error.message}`, true);
    } finally {
      button.disabled = false;
      button.textContent = "Import previous data";
    }
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[character]);
  }

  function initials(name) {
    return name.trim().split(/\s+/).slice(0, 2).map(part => part.charAt(0)).join("").toUpperCase() || "?";
  }

  function toneFor(name) {
    return Array.from(name).reduce((sum, character) => sum + character.charCodeAt(0), 0) % 5;
  }

  function formatDate(dateString) {
    if (!dateString) return "";
    const parts = dateString.split("-").map(Number);
    if (parts.length !== 3 || parts.some(Number.isNaN)) return dateString;
    return new Date(parts[0], parts[1] - 1, parts[2]).toLocaleDateString(undefined, {
      month: "short", day: "numeric", year: "numeric"
    });
  }

  function recordFor(studentId, date) {
    return state.records.find(record => record.studentId === studentId && record.date === date);
  }

  function normalizeYearLevel(yearLevel, section) {
    const validLevels = ["1st Year", "2nd Year", "3rd Year", "4th Year"];
    if (validLevels.includes(yearLevel)) return yearLevel;
    const combined = /^(\d+(?:st|nd|rd|th)\s+Year)\s*[–-]/i.exec(section || "");
    const sectionLevel = combined && validLevels.find(level => level.toLocaleLowerCase() === combined[1].toLocaleLowerCase());
    return sectionLevel || "";
  }

  function sectionLetter(section) {
    const combined = /\d+(?:st|nd|rd|th)\s+Year\s*[–-]\s*([A-Z])/i.exec(section || "");
    if (combined) return combined[1].toUpperCase();
    return /^[A-Z]$/i.test(section || "") ? section.toUpperCase() : section || "";
  }

  function studentYearAndSection(yearLevel, section) {
    const letter = sectionLetter(section);
    return [yearLevel, letter].filter(Boolean).join(" – ");
  }

  function studentCell(name, subtitle) {
    const safeName = escapeHTML(name);
    return `<div class="student-cell"><span class="student-avatar tone-${toneFor(name)}">${escapeHTML(initials(name))}</span><span><span class="student-name">${safeName}</span>${subtitle ? `<span class="student-subtext">${escapeHTML(subtitle)}</span>` : ""}</span></div>`;
  }

  function courseCell(course, section) {
    return `<span class="course-name">${escapeHTML(course)}</span>${section ? `<span class="student-subtext course-section">${escapeHTML(section)}</span>` : ""}`;
  }

  function statusBadge(status) {
    const className = status === "Present" ? "status-present" :
      status === "Late" ? "status-late" :
        status === "Absent" ? "status-absent" : "status-unmarked";
    return `<span class="status-badge ${className}">${status || "Not marked"}</span>`;
  }

  function animateNumber(element, target, suffix = "") {
    const currentText = element.textContent.replace(/[^\d.-]/g, "");
    const start = Number(currentText) || 0;
    const end = Number(target) || 0;
    const previousAnimation = numberAnimations.get(element);
    if (previousAnimation) window.cancelAnimationFrame(previousAnimation);

    if (reducedMotion.matches || start === end) {
      element.textContent = `${end}${suffix}`;
      return;
    }

    const startedAt = performance.now();
    const duration = 720;
    const update = now => {
      const progress = Math.min((now - startedAt) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 4);
      element.textContent = `${Math.round(start + (end - start) * eased)}${suffix}`;
      if (progress < 1) {
        numberAnimations.set(element, window.requestAnimationFrame(update));
      } else {
        numberAnimations.delete(element);
      }
    };
    numberAnimations.set(element, window.requestAnimationFrame(update));
  }

  function animateDonut(targetPercentage) {
    window.cancelAnimationFrame(donutAnimation);
    const start = donutProgress;
    const end = Math.max(0, Math.min(100, targetPercentage)) * 3.6;
    if (reducedMotion.matches) {
      donutProgress = end;
      document.getElementById("attendanceDonut").style.setProperty("--donut-progress", `${end}deg`);
      return;
    }
    const startedAt = performance.now();
    const duration = 850;
    const update = now => {
      const progress = Math.min((now - startedAt) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      donutProgress = start + (end - start) * eased;
      document.getElementById("attendanceDonut").style.setProperty("--donut-progress", `${donutProgress}deg`);
      if (progress < 1) donutAnimation = window.requestAnimationFrame(update);
    };
    donutAnimation = window.requestAnimationFrame(update);
  }

  function animateRows(tbody) {
    Array.from(tbody.rows).forEach((row, index) => {
      row.classList.add("row-enter");
      row.style.setProperty("--row-index", Math.min(index, 6));
    });
  }

  function render() {
    renderDashboard();
    renderStudents();
    renderAttendance();
    renderRecords();
  }

  function renderDashboard() {
    const activeStudentIds = new Set(state.students.map(student => student.id));
    const todayRecords = state.records.filter(record => record.date === today && activeStudentIds.has(record.studentId));
    const present = todayRecords.filter(record => record.status === "Present").length;
    const late = todayRecords.filter(record => record.status === "Late").length;
    const absent = todayRecords.filter(record => record.status === "Absent").length;
    const percentage = state.students.length ? Math.round(((present + late) / state.students.length) * 100) : 0;
    animateNumber(document.getElementById("totalStudents"), state.students.length);
    animateNumber(document.getElementById("presentStudents"), present);
    animateNumber(document.getElementById("absentStudents"), absent);
    animateNumber(document.getElementById("attendancePercentage"), percentage);
    animateNumber(document.getElementById("donutPercentage"), percentage, "%");
    document.getElementById("legendPresent").textContent = present;
    document.getElementById("legendLate").textContent = late;
    document.getElementById("legendAbsent").textContent = absent;
    document.getElementById("legendTotal").textContent = state.students.length;
    document.getElementById("dashboardDate").textContent = formatDate(today);
    document.getElementById("headerDate").textContent = new Date().toLocaleDateString(undefined, {
      weekday: "short", month: "short", day: "numeric"
    });
    animateDonut(percentage);

    const recent = [...state.students].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 4);
    const recentBody = document.getElementById("recentStudentsBody");
    recentBody.innerHTML = recent.map(student => {
      const status = recordFor(student.id, today);
      return `<tr><td>${studentCell(student.name)}</td><td class="id-cell">${escapeHTML(student.id)}</td><td class="course-cell">${courseCell(student.course, studentYearAndSection(student.yearLevel, student.section))}</td><td>${statusBadge(status && status.status)}</td></tr>`;
    }).join("");
    animateRows(recentBody);
    document.getElementById("recentStudentsEmpty").hidden = state.students.length > 0;
    document.querySelector(".recent-panel .table-wrap table").hidden = state.students.length === 0;

    const activityTimestamp = record => Date.parse(record.timeOutRaw || record.timeInRaw || `${record.date}T00:00:00`);
    const recentActivity = [...state.records]
      .sort((a, b) => activityTimestamp(b) - activityTimestamp(a))
      .slice(0, 5);
    const activityBody = document.getElementById("recentActivityBody");
    activityBody.innerHTML = recentActivity.map(record => `<tr>
      <td>${studentCell(record.name)}</td>
      <td class="id-cell">${escapeHTML(record.studentId)}</td>
      <td>${escapeHTML(formatDate(record.date))}</td>
      <td>${escapeHTML(record.timeIn || "—")}</td>
      <td>${escapeHTML(record.timeOut || "—")}</td>
      <td>${statusBadge(record.status)}</td>
    </tr>`).join("");
    animateRows(activityBody);
    document.getElementById("recentActivityEmpty").hidden = recentActivity.length > 0;
    document.querySelector(".activity-panel .table-wrap table").hidden = recentActivity.length === 0;
  }

  function renderStudents() {
    const query = document.getElementById("studentSearch").value.trim().toLocaleLowerCase();
    const students = [...state.students]
      .sort((a, b) => a.name.localeCompare(b.name))
      .filter(student => `${student.name} ${student.id} ${student.course} ${studentYearAndSection(student.yearLevel, student.section)}`.toLocaleLowerCase().includes(query));
    document.getElementById("studentCount").textContent = state.students.length;
    document.getElementById("studentsBody").innerHTML = students.map(student => {
      const added = student.createdAt ? formatDate(student.createdAt.slice(0, 10)) : "—";
      return `<tr>
        <td>${studentCell(student.name)}</td>
        <td class="id-cell">${escapeHTML(student.id)}</td>
        <td class="course-cell">${courseCell(student.course, studentYearAndSection(student.yearLevel, student.section))}</td>
        <td>${escapeHTML(added)}</td>
        <td><div class="row-actions">
          <button class="icon-button" type="button" data-action="view-qr" data-id="${escapeHTML(student.id)}" aria-label="View QR code for ${escapeHTML(student.name)}" title="View QR code">▦</button>
          <button class="icon-button" type="button" data-action="edit-student" data-id="${escapeHTML(student.id)}" aria-label="Edit ${escapeHTML(student.name)}" title="Edit student">✎</button>
          <button class="icon-button delete-button" type="button" data-action="delete-student" data-id="${escapeHTML(student.id)}" aria-label="Delete ${escapeHTML(student.name)}" title="Delete student">×</button>
        </div></td>
      </tr>`;
    }).join("");
    animateRows(document.getElementById("studentsBody"));
    const empty = students.length === 0;
    document.getElementById("studentsEmpty").hidden = !empty;
    document.querySelector("#page-students .table-wrap table").hidden = empty;
    if (empty) {
      const hasStudents = state.students.length > 0;
      document.getElementById("studentsEmptyTitle").textContent = hasStudents ? "No matching students" : "No students yet";
      document.getElementById("studentsEmptyText").textContent = hasStudents ? "Try a different name, ID, or course." : "Add your first student to get started.";
      document.getElementById("studentsEmptyAction").hidden = hasStudents;
    }
  }

  function renderAttendance() {
    const dateInput = document.getElementById("attendanceDate");
    if (!dateInput.value) dateInput.value = today;
    const date = dateInput.value;
    let present = 0;
    let late = 0;
    let absent = 0;
    document.getElementById("attendanceBody").innerHTML = [...state.students]
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(student => {
        const record = recordFor(student.id, date);
        if (record && record.status === "Present") present += 1;
        if (record && record.status === "Late") late += 1;
        if (record && record.status === "Absent") absent += 1;
        return `<tr>
          <td>${studentCell(student.name)}</td>
          <td class="id-cell">${escapeHTML(student.id)}</td>
          <td class="course-cell">${courseCell(student.course, studentYearAndSection(student.yearLevel, student.section))}</td>
          <td><div class="attendance-row-status">
            <button class="status-toggle ${record && record.status === "Present" ? "present-selected" : ""}" type="button" data-action="mark-attendance" data-id="${escapeHTML(student.id)}" data-status="Present" aria-pressed="${Boolean(record && record.status === "Present")}">✓ Present</button>
            <button class="status-toggle ${record && record.status === "Late" ? "late-selected" : ""}" type="button" data-action="mark-attendance" data-id="${escapeHTML(student.id)}" data-status="Late" aria-pressed="${Boolean(record && record.status === "Late")}">◷ Late</button>
            <button class="status-toggle ${record && record.status === "Absent" ? "absent-selected" : ""}" type="button" data-action="mark-attendance" data-id="${escapeHTML(student.id)}" data-status="Absent" aria-pressed="${Boolean(record && record.status === "Absent")}">× Absent</button>
          </div></td>
        </tr>`;
      }).join("");
    animateRows(document.getElementById("attendanceBody"));
    document.getElementById("attendancePresentCount").textContent = present;
    document.getElementById("attendanceLateCount").textContent = late;
    document.getElementById("attendanceAbsentCount").textContent = absent;
    document.getElementById("attendanceFootDate").textContent = formatDate(date);
    const empty = state.students.length === 0;
    document.getElementById("attendanceEmpty").hidden = !empty;
    document.querySelector("#page-attendance .table-wrap table").hidden = empty;
    document.getElementById("markAllPresent").disabled = empty;
    document.getElementById("markAllPresent").style.opacity = empty ? ".55" : "1";
  }

  function renderRecords() {
    const query = document.getElementById("recordSearch").value.trim().toLocaleLowerCase();
    const status = document.getElementById("statusFilter").value;
    const records = [...state.records]
      .sort((a, b) => b.date.localeCompare(a.date) || a.name.localeCompare(b.name))
      .filter(record => (status === "all" || record.status === status) &&
        `${record.name} ${record.studentId} ${record.course} ${record.date} ${formatDate(record.date)}`.toLocaleLowerCase().includes(query));
    document.getElementById("recordCount").textContent = state.records.length;
    document.getElementById("recordsBody").innerHTML = records.map(record => `<tr>
      <td>${studentCell(record.name)}</td>
      <td class="id-cell">${escapeHTML(record.studentId)}</td>
      <td class="course-cell">${courseCell(record.course, studentYearAndSection(record.yearLevel, record.section))}</td>
      <td>${escapeHTML(formatDate(record.date))}</td>
      <td>${escapeHTML(record.timeIn || "—")}</td>
      <td>${escapeHTML(record.timeOut || "—")}</td>
      <td>${statusBadge(record.status)}</td>
      <td><div class="row-actions"><button class="icon-button delete-button" type="button" data-action="delete-record" data-id="${escapeHTML(record.studentId)}" data-date="${escapeHTML(record.date)}" aria-label="Delete ${escapeHTML(record.name)} attendance record" title="Delete record">×</button></div></td>
    </tr>`).join("");
    animateRows(document.getElementById("recordsBody"));
    const empty = records.length === 0;
    document.getElementById("recordsEmpty").hidden = !empty;
    document.querySelector("#page-records .table-wrap table").hidden = empty;
    if (empty) {
      const hasRecords = state.records.length > 0;
      document.getElementById("recordsEmptyTitle").textContent = hasRecords ? "No matching records" : "No attendance records";
      document.getElementById("recordsEmptyText").textContent = hasRecords ? "Try another search or status filter." : "Take attendance to create your first record.";
      document.getElementById("recordsEmptyAction").hidden = hasRecords;
    }
  }

  function renderEvents() {
    const activeId = state.events.find(event => event.active)?.id || "regular";
    const sessionSelect = document.getElementById("activeSessionSelect");
    sessionSelect.innerHTML = `<option value="regular">Regular School Attendance</option>${state.events.map(event =>
      `<option value="${escapeHTML(event.id)}">${escapeHTML(event.name)} — ${escapeHTML(formatDate(event.date))}</option>`
    ).join("")}`;
    sessionSelect.value = activeId;
    if (!sessionSelect.value) sessionSelect.value = "regular";

    const eventsBody = document.getElementById("eventsBody");
    eventsBody.innerHTML = [...state.events].sort((a, b) => b.date.localeCompare(a.date)).map(event => `
      <tr>
        <td><strong>${escapeHTML(event.name)}</strong></td>
        <td>${escapeHTML(formatDate(event.date))}<span class="student-subtext">${escapeHTML(event.location)}</span></td>
        <td>${event.enableFines ? "Enabled" : "Disabled"}</td>
        <td>${event.active ? '<span class="event-session-active">Active</span>' : "Inactive"}</td>
        <td><div class="row-actions">
          <button class="button button-secondary button-small" type="button" data-action="edit-event" data-id="${escapeHTML(event.id)}">Edit</button>
          <button class="button button-secondary button-small" type="button" data-action="${event.active ? "deactivate-event" : "activate-event"}" data-id="${escapeHTML(event.id)}">${event.active ? "Use Regular" : "Set Active"}</button>
          <button class="icon-button delete-button" type="button" data-action="delete-event" data-id="${escapeHTML(event.id)}" aria-label="Delete ${escapeHTML(event.name)}">×</button>
        </div></td>
      </tr>`).join("");
    const empty = state.events.length === 0;
    document.getElementById("eventsEmpty").hidden = !empty;
    document.querySelector("#page-events table").hidden = empty;
    renderActiveSession();
  }

  function renderActiveSession() {
    const event = state.events.find(item => item.active);
    const date = document.getElementById("qrAttendanceDate").value || today;
    const currentTitle = document.getElementById("currentAttendanceTitle");
    const finesStatus = document.getElementById("currentAttendanceFines");
    const summary = document.getElementById("qrScheduleSummary");
    if (!event) {
      currentTitle.textContent = "Regular School Attendance";
      finesStatus.textContent = "Fines: DISABLED";
      renderScheduleSummary();
      return;
    }
    currentTitle.textContent = event.name;
    finesStatus.textContent = `Fines: ${event.enableFines ? "ENABLED" : "DISABLED"}`;
    if (date !== event.date) {
      summary.textContent = `This event is scheduled for ${formatDate(event.date)}. Set the attendance date to scan for this event.`;
      return;
    }
    const labels = [
      ["Morning Sign In", event.periods.morningSignIn],
      ["Morning Sign Out", event.periods.morningSignOut],
      ["Afternoon Sign In", event.periods.afternoonSignIn],
      ["Afternoon Sign Out", event.periods.afternoonSignOut]
    ];
    summary.textContent = labels.map(([label, range]) =>
      `${label}: ${formatEventTime(range[0])}–${formatEventTime(range[1])}`
    ).join(" · ");
  }

  function formatEventTime(value) {
    if (!value) return "Not set";
    const [hour, minute] = value.slice(0, 5).split(":").map(Number);
    return new Date(2000, 0, 1, hour, minute).toLocaleTimeString([], { hour: "numeric", minute: "2-digit", hour12: true });
  }

  function renderFines() {
    const studentSearch = document.getElementById("fineSearch").value.trim().toLocaleLowerCase();
    const studentsById = new Map(state.students.map(student => [student.id, student]));
    const groupedFines = new Map();
    state.fines.forEach(fine => {
      let group = groupedFines.get(fine.student_id);
      if (!group) {
        const student = studentsById.get(fine.student_id);
        group = {
          studentId: fine.student_id,
          name: student ? student.name : fine.full_name,
          fines: [],
          total: 0,
          unpaid: 0,
          paidCount: 0
        };
        groupedFines.set(fine.student_id, group);
      }
      const amount = Number(fine.amount);
      group.fines.push(fine);
      group.total += amount;
      if (fine.payment_status === "Paid") group.paidCount += 1;
      if (fine.payment_status === "Unpaid") group.unpaid += amount;
    });
    const students = [...groupedFines.values()]
      .filter(group => !studentSearch ||
        group.name.toLocaleLowerCase().includes(studentSearch) ||
        String(group.studentId).toLocaleLowerCase().includes(studentSearch))
      .sort((a, b) => a.name.localeCompare(b.name) || String(a.studentId).localeCompare(String(b.studentId)));
    const body = document.getElementById("finesBody");
    body.innerHTML = students.map(group => {
      const paymentStatus = group.paidCount === group.fines.length ? "Paid" :
        group.paidCount > 0 ? "Partially Paid" : "Unpaid";
      const statusClass = paymentStatus === "Paid" ? "fine-status-paid" :
        paymentStatus === "Partially Paid" ? "fine-status-partial" : "fine-status-unpaid";
      return `<tr>
      <td>${studentCell(group.name)}</td>
      <td class="id-cell">${escapeHTML(group.studentId)}</td>
      <td>₱${group.total.toFixed(0)}</td>
      <td>₱${group.unpaid.toFixed(0)}</td>
      <td><span class="fine-payment-status ${statusClass}">${paymentStatus}</span></td>
      <td><button class="button button-secondary button-small fine-history-button" type="button" data-action="view-fine-history" data-id="${escapeHTML(group.studentId)}">👁 View History</button></td>
    </tr>`;
    }).join("");
    const empty = students.length === 0;
    document.getElementById("finesEmpty").hidden = !empty;
    document.querySelector("#page-fines table").hidden = empty;
    document.getElementById("fineCount").textContent = students.reduce((total, group) => total + group.fines.length, 0);
    document.getElementById("finesEmptyTitle").textContent = studentSearch
      ? "No student fine records found."
      : "No event fines";
    document.getElementById("finesEmptyText").textContent = studentSearch
      ? "Try another student name or Student ID."
      : "Missed event attendance actions will appear here when their periods close.";
    const unpaidTotal = state.fines.reduce((total, fine) =>
      total + (fine.payment_status === "Unpaid" ? Number(fine.amount) : 0), 0);
    document.getElementById("totalUnpaidFines").textContent = `₱${unpaidTotal.toFixed(0)}`;
  }

  function openFineHistory(studentId) {
    fineHistoryStudentId = studentId;
    document.getElementById("fineHistoryEventFilter").value = "all";
    document.getElementById("fineHistoryDateFilter").value = "";
    document.getElementById("fineHistoryPaymentFilter").value = "all";
    renderFineHistory();
    document.getElementById("fineHistoryDialog").showModal();
  }

  function renderFineHistory() {
    if (!fineHistoryStudentId) return;
    const history = state.fines.filter(fine => fine.student_id === fineHistoryStudentId);
    const snapshot = state.fines.find(fine => fine.student_id === fineHistoryStudentId);
    const student = state.students.find(item => item.id === fineHistoryStudentId);
    if (!snapshot && !student) return;

    document.getElementById("fineHistoryStudentName").textContent = student ? student.name : snapshot.full_name;
    document.getElementById("fineHistoryStudentId").textContent = fineHistoryStudentId;
    const course = student ? student.course : snapshot.course;
    const yearLevel = student ? student.yearLevel : snapshot.year_level;
    const section = student ? sectionLetter(student.section) : snapshot.section;
    document.getElementById("fineHistoryStudentDetails").textContent =
      [course, yearLevel, section].filter(Boolean).join(" · ");

    const eventFilter = document.getElementById("fineHistoryEventFilter");
    const selectedEvent = eventFilter.value || "all";
    const eventOptions = new Map();
    history.forEach(fine => eventOptions.set(fine.event_id, `${fine.event_name} — ${formatDate(fine.event_date)}`));
    eventFilter.innerHTML = `<option value="all">All events</option>${[...eventOptions.entries()].map(([id, label]) =>
      `<option value="${escapeHTML(id)}">${escapeHTML(label)}</option>`
    ).join("")}`;
    eventFilter.value = eventOptions.has(selectedEvent) ? selectedEvent : "all";

    const dateFilter = document.getElementById("fineHistoryDateFilter").value;
    const paymentFilter = document.getElementById("fineHistoryPaymentFilter").value;
    const filtered = history.filter(fine =>
      (eventFilter.value === "all" || fine.event_id === eventFilter.value) &&
      (!dateFilter || fine.event_date === dateFilter) &&
      (paymentFilter === "all" || fine.payment_status === paymentFilter)
    ).sort((a, b) => b.event_date.localeCompare(a.event_date) ||
      b.created_at.localeCompare(a.created_at) || a.missed_action.localeCompare(b.missed_action));

    const total = filtered.reduce((sum, fine) => sum + Number(fine.amount), 0);
    const paid = filtered.reduce((sum, fine) => sum + (fine.payment_status === "Paid" ? Number(fine.amount) : 0), 0);
    const unpaid = filtered.reduce((sum, fine) => sum + (fine.payment_status === "Unpaid" ? Number(fine.amount) : 0), 0);
    document.getElementById("fineHistoryTotal").textContent = `₱${total.toFixed(0)}`;
    document.getElementById("fineHistoryPaid").textContent = `₱${paid.toFixed(0)}`;
    document.getElementById("fineHistoryUnpaid").textContent = `₱${unpaid.toFixed(0)}`;
    document.getElementById("fineHistoryMissedCount").textContent = filtered.length;

    const groups = new Map();
    filtered.forEach(fine => {
      if (!groups.has(fine.event_id)) groups.set(fine.event_id, []);
      groups.get(fine.event_id).push(fine);
    });
    document.getElementById("fineHistoryEvents").innerHTML = [...groups.entries()].map(([, eventFines]) => {
      const event = eventFines[0];
      const eventTotal = eventFines.reduce((sum, fine) => sum + Number(fine.amount), 0);
      return `<section class="fine-history-event">
        <div class="fine-history-event-heading"><h3>${escapeHTML(event.event_name)} — ${escapeHTML(formatDate(event.event_date))}</h3><strong>Event Total: ₱${eventTotal.toFixed(0)}</strong></div>
        <div class="table-wrap"><table><thead><tr><th>DATE</th><th>EVENT</th><th>EVENT DATE</th><th>MISSED ACTION</th><th>REASON</th><th>FINE</th><th>STATUS</th></tr></thead><tbody>
          ${eventFines.map(fine => {
            const fineDate = fine.created_at ? formatDate(toLocalDateInputValue(new Date(fine.created_at))) : "—";
            return `<tr>
              <td>${escapeHTML(fineDate)}</td>
              <td>${escapeHTML(fine.event_name)}</td>
              <td>${escapeHTML(formatDate(fine.event_date))}</td>
              <td>${escapeHTML(fine.missed_action)}</td>
              <td class="fine-reason">${escapeHTML(fine.reason || `Did not scan during ${fine.missed_action}`)}</td>
              <td>₱${Number(fine.amount).toFixed(0)}</td>
              <td><button class="fine-paid-toggle" type="button" data-action="toggle-fine-payment" data-id="${escapeHTML(fine.id)}">${escapeHTML(fine.payment_status)}</button></td>
            </tr>`;
          }).join("")}
        </tbody></table></div>
      </section>`;
    }).join("");
    document.getElementById("fineHistoryEmpty").hidden = filtered.length > 0;
  }

  function showPage(pageName) {
    if (!pageNames[pageName]) return;
    if (document.getElementById("page-qr-attendance").classList.contains("active") && pageName !== "qr-attendance") {
      stopQRScanner();
    }
    elements.pages.forEach(page => {
      const active = page.id === `page-${pageName}`;
      page.classList.toggle("active", active);
      page.hidden = !active;
    });
    elements.navLinks.forEach(link => {
      const active = link.dataset.page === pageName;
      link.classList.toggle("active", active);
      if (active) link.setAttribute("aria-current", "page");
      else link.removeAttribute("aria-current");
    });
    document.getElementById("currentPageLabel").textContent = pageNames[pageName];
    closeMobileNav();
    if (pageName === "attendance") renderAttendance();
    if (pageName === "qr-attendance") {
      const dateInput = document.getElementById("qrAttendanceDate");
      if (!dateInput.value) dateInput.value = today;
      renderActiveSession();
    }
    if (pageName === "events") renderEvents();
    if (pageName === "fines") finalizeMissedFines();
    if (pageName === "settings") renderScheduleForm();
    const currentPage = document.getElementById(`page-${pageName}`);
    currentPage.classList.remove("page-enter");
    if (!reducedMotion.matches) {
      void currentPage.offsetWidth;
      currentPage.classList.add("page-enter");
    }
  }

  function openStudentDialog(student) {
    const editing = Boolean(student);
    document.getElementById("dialogTitle").textContent = editing ? "Edit student" : "Add a student";
    document.getElementById("saveStudentButton").textContent = editing ? "Save changes" : "Add student";
    document.getElementById("studentOriginalId").value = editing ? student.id : "";
    const studentIdInput = document.getElementById("studentId");
    studentIdInput.value = editing ? student.id : "";
    studentIdInput.readOnly = false;
    document.getElementById("studentIdHelp").textContent = editing
      ? "Enter a unique Student ID. Year Level is selected separately."
      : "Enter a unique Student ID.";
    document.getElementById("studentName").value = editing ? student.name : "";
    document.getElementById("studentCourse").value = editing ? student.course : "";
    document.getElementById("courseSelectedLabel").textContent = editing ? student.course : "Select a course";
    document.getElementById("studentYearLevel").value = editing ? student.yearLevel : "";
    document.getElementById("studentSection").value = editing ? sectionLetter(student.section) : "";
    document.getElementById("courseSearch").value = "";
    renderCourseOptions("");
    closeCourseMenu();
    document.getElementById("formError").hidden = true;
    elements.dialog.showModal();
    if (editing) studentIdInput.focus();
    else document.getElementById("studentName").focus();
  }

  function showScannedStudent(student) {
    document.getElementById("qrResultName").textContent = student.name;
    document.getElementById("qrResultId").textContent = `Student ID: ${student.id}`;
    document.getElementById("qrResultCourse").textContent = student.course;
    document.getElementById("qrResultYear").textContent =
      `Year Level / Section: ${studentYearAndSection(student.yearLevel, student.section) || "Not available"}`;
    document.getElementById("qrStudentResult").hidden = false;
  }

  function renderCourseOptions(query) {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    const filteredCourses = courses.filter(course =>
      `${course.name} ${course.group}`.toLocaleLowerCase().includes(normalizedQuery)
    );
    const options = document.getElementById("courseOptions");
    let activeGroup = "";
    options.innerHTML = filteredCourses.map(course => {
      const groupLabel = course.group !== activeGroup
        ? `<div class="course-group-label">${escapeHTML(course.group)}</div>`
        : "";
      activeGroup = course.group;
      const selected = document.getElementById("studentCourse").value === course.name;
      return `${groupLabel}<button class="course-option${selected ? " selected" : ""}" type="button" role="option" aria-selected="${selected}" data-course="${escapeHTML(course.name)}">${escapeHTML(course.name)}</button>`;
    }).join("");
    document.getElementById("courseNoResults").hidden = filteredCourses.length > 0;
  }

  function openCourseMenu() {
    const menu = document.getElementById("courseMenu");
    menu.classList.add("open");
    menu.setAttribute("aria-hidden", "false");
    document.getElementById("courseTrigger").setAttribute("aria-expanded", "true");
    document.getElementById("courseSearch").focus();
  }

  function closeCourseMenu() {
    const menu = document.getElementById("courseMenu");
    menu.classList.remove("open");
    menu.setAttribute("aria-hidden", "true");
    document.getElementById("courseTrigger").setAttribute("aria-expanded", "false");
  }

  async function handleStudentSubmit(event) {
    event.preventDefault();
    const originalId = document.getElementById("studentOriginalId").value;
    const id = document.getElementById("studentId").value.trim();
    const name = document.getElementById("studentName").value.trim();
    const course = document.getElementById("studentCourse").value;
    const yearLevel = document.getElementById("studentYearLevel").value;
    const section = document.getElementById("studentSection").value;
    const duplicate = state.students.some(student =>
      student.id.toLocaleLowerCase() === id.toLocaleLowerCase() && student.id !== originalId
    );
    if (!id || !name || !course || !yearLevel || !section) {
      showFormError("Please complete all required fields.");
      return;
    }
    if (duplicate) {
      showFormError("That student ID is already in use. Please enter a unique ID.");
      document.getElementById("studentId").focus();
      return;
    }

    try {
      const { error } = await supabaseClient.rpc("save_student", {
        p_original_student_id: originalId || null,
        p_student_id: id,
        p_full_name: name,
        p_course: course,
        p_year_level: yearLevel,
        p_section: section
      });
      if (error) throw error;
      elements.dialog.close();
      await reloadRemoteData();
      showToast(originalId ? "Student details updated successfully!" : "Student added successfully!");
    } catch (error) {
      console.error("Could not save student to Supabase.", error);
      showFormError(error.code === "23505"
        ? "That student ID is already in use. Please enter a unique ID."
        : `Could not save student: ${error.message}`);
    }
  }

  function showFormError(message) {
    const error = document.getElementById("formError");
    error.textContent = message;
    error.hidden = false;
  }

  async function markAttendance(studentId, status, date) {
    const student = state.students.find(item => item.id === studentId);
    if (!student) return;
    const record = recordFor(studentId, date);
    try {
      const { error } = await supabaseClient.from("attendance").upsert({
        ...databaseStudentPayload(student),
        student_id: student.id,
        attendance_date: date,
        time_in: record ? record.timeInRaw : null,
        time_out: record ? record.timeOutRaw : null,
        status
      }, { onConflict: "student_id,attendance_date" });
      if (error) throw error;
      await reloadRemoteData();
      showToast("Attendance saved successfully!");
    } catch (error) {
      console.error("Could not save attendance to Supabase.", error);
      showToast(`Could not save attendance: ${error.message}`, true);
    }
  }

  function qrPayloadFor(student) {
    return `CC101|${student.id}`;
  }

  function openStudentQRCode(student) {
    if (typeof window.QRCode !== "function") {
      document.getElementById("qrLibraryNotice").hidden = false;
      document.getElementById("studentQRCode").replaceChildren();
    } else {
      document.getElementById("qrLibraryNotice").hidden = true;
      const container = document.getElementById("studentQRCode");
      container.replaceChildren();
      new window.QRCode(container, {
        text: qrPayloadFor(student),
        width: 280,
        height: 280,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: window.QRCode.CorrectLevel.Q
      });
    }
    document.getElementById("qrDialogTitle").textContent = `QR code — ${student.name}`;
    document.getElementById("qrStudentName").textContent = student.name;
    document.getElementById("qrStudentId").textContent = `Student ID: ${student.id}`;
    document.getElementById("qrStudentCourse").textContent = student.course;
    document.getElementById("qrStudentSection").textContent = studentYearAndSection(student.yearLevel, student.section);
    const qrPayload = qrPayloadFor(student);
    document.getElementById("qrStudentPayload").textContent = qrPayload;
    document.getElementById("copyQRCodeValue").dataset.payload = qrPayload;
    elements.qrDialog.showModal();
  }

  function setQRScanMessage(message, isError = false) {
    const messageElement = document.getElementById("qrScanMessage");
    messageElement.textContent = message;
    messageElement.classList.toggle("error", isError);
  }

  function studentIdFromQR(value) {
    const text = value.trim();
    if (!text) throw new Error("Enter or scan a QR code value.");
    const compactText = text.replace(/\s+/g, "");
    if (/^CC101\|/i.test(compactText)) {
      const studentId = compactText.slice("CC101|".length);
      if (!studentId) {
        throw new Error("That QR code does not contain a Student ID.");
      }
      return studentId;
    }
    if (!text.startsWith("{")) {
      if (compactText.includes("|")) throw new Error("Invalid QR code. Use CC101|StudentID or enter a Student ID.");
      return compactText;
    }
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (error) {
      throw new Error("That QR code value is not valid. Please scan or paste a valid student QR code.");
    }
    if (!payload || payload.type !== "cc101-student" || typeof payload.studentId !== "string") {
      throw new Error("That QR code does not belong to a registered student.");
    }
    return payload.studentId.trim();
  }

  function studentForQR(value) {
    const studentId = studentIdFromQR(value).replace(/\s+/g, "").toLocaleUpperCase();
    const student = state.students.find(item =>
      item.id.replace(/\s+/g, "").toLocaleUpperCase() === studentId
    );
    if (!student) throw new Error("No registered student matches that QR code or Student ID.");
    return student;
  }

  async function recordQRAttendance(value) {
    const now = new Date();
    const date = document.getElementById("qrAttendanceDate").value || today;
    const localTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    try {
      const { data, error } = await supabaseClient.rpc("scan_attendance_session", {
        p_qr_value: value,
        p_attendance_date: date,
        p_local_time: localTime,
        p_scanned_at: now.toISOString()
      });
      if (error) throw error;
      const result = Array.isArray(data) ? data[0] : data;
      if (!result) throw new Error("The attendance service returned no result.");
      if (result.full_name) {
        const knownStudent = state.students.find(student =>
          student.id.toLocaleUpperCase() === String(result.student_id || "").toLocaleUpperCase()
        );
        showScannedStudent(knownStudent || {
          id: result.student_id,
          name: result.full_name,
          course: result.course,
          yearLevel: result.year_level,
          section: result.section
        });
      }
      const messages = {
        event_signed: `✅ ${result.full_name} recorded for ${result.action} — ${result.event_name}.`,
        event_action_already_recorded: `${result.action} has already been recorded for this event.`,
        event_period_not_open: "No event attendance period is open right now.",
        event_date_mismatch: `The active event is on ${formatDate(result.event_date)}. Change the attendance date to scan.`,
        regular_action_signed: `✅ ${result.full_name} recorded for ${result.action}.`,
        regular_action_already_recorded: `${result.action} has already been recorded for regular attendance.`,
        regular_period_not_open: "No regular attendance period is open right now.",
        signed_in: `✅ Welcome, ${result.full_name}! Successfully signed in.`,
        signed_out: `👋 Goodbye, ${result.full_name}! Successfully signed out.`,
        already_complete: "⚠️ Attendance already completed for today.",
        sign_in_not_open: "⏳ Sign-in is not available yet.",
        sign_in_closed: "❌ Sign-in is closed. The attendance deadline has passed.",
        sign_out_not_open: "⏳ Sign-out is not available yet.",
        sign_out_closed: "❌ Sign-out is closed.",
        schedule_not_configured: "Sign-in schedule is not configured. Please ask the administrator to set it.",
        student_not_found: "No registered student matches that QR code or Student ID.",
        invalid_qr: "Invalid QR code. Use the existing CC101|StudentID QR or enter a Student ID.",
        auth_required: "Your session is not authorized to record attendance. Sign in with an approved administrator account."
      };
      const message = messages[result.result] || result.message || "Attendance could not be processed.";
      const successful = ["signed_in", "signed_out", "event_signed", "regular_action_signed"].includes(result.result);
      if (successful) await reloadRemoteData();
      setQRScanMessage(message, !successful);
      return successful;
    } catch (error) {
      console.error("Could not process QR attendance through Supabase.", error);
      setQRScanMessage(`Could not save attendance online: ${error.message}`, true);
      return false;
    }
  }

  function timeInMinutes(value) {
    const time = normalizeScheduleTime(value);
    if (!time) return null;
    const hour = Number(time.hour) % 12 + (time.period === "PM" ? 12 : 0);
    return hour * 60 + Number(time.minute);
  }

  function formatScheduleTime(value) {
    const time = normalizeScheduleTime(value);
    if (!time) return "Not set";
    return `${Number(time.hour)}:${time.minute} ${time.period}`;
  }

  function renderScheduleSummary() {
    const { signInStart, signInEnd, signOutStart, signOutEnd,
      afternoonSignInStart, afternoonSignInEnd, afternoonSignOutStart, afternoonSignOutEnd } = state.schedule;
    const signOutSummary = signOutStart && signOutEnd
      ? `${formatScheduleTime(signOutStart)}–${formatScheduleTime(signOutEnd)}`
      : signOutStart
        ? `After ${formatScheduleTime(signOutStart)}`
        : signOutEnd
          ? `Until ${formatScheduleTime(signOutEnd)}`
          : "Anytime";
    document.getElementById("qrScheduleSummary").textContent =
      `Morning sign-in: ${formatScheduleTime(signInStart)}–${formatScheduleTime(signInEnd)} · Morning sign-out: ${signOutSummary}` +
      (afternoonSignInStart && afternoonSignInEnd
        ? ` · Afternoon sign-in: ${formatScheduleTime(afternoonSignInStart)}–${formatScheduleTime(afternoonSignInEnd)}` : "") +
      (afternoonSignOutStart && afternoonSignOutEnd
        ? ` · Afternoon sign-out: ${formatScheduleTime(afternoonSignOutStart)}–${formatScheduleTime(afternoonSignOutEnd)}` : "");
  }

  function renderScheduleForm() {
    Object.keys(state.schedule).forEach(key => setScheduleTimeControls(key, state.schedule[key]));
    document.getElementById("scheduleError").hidden = true;
    document.getElementById("scheduleSavedMessage").textContent = "";
  }

  function setScheduleTimeControls(key, value) {
    const time = normalizeScheduleTime(value);
    const hourSelect = document.getElementById(`${key}Hour`);
    const minuteSelect = document.getElementById(`${key}Minute`);
    const periodSelect = document.getElementById(`${key}Period`);
    if (time && !Array.from(minuteSelect.options).some(option => option.value === time.minute)) {
      const savedMinute = document.createElement("option");
      savedMinute.value = time.minute;
      savedMinute.textContent = time.minute;
      minuteSelect.append(savedMinute);
    }
    hourSelect.value = time ? time.hour : "";
    minuteSelect.value = time ? time.minute : "";
    periodSelect.value = time ? time.period : "";
  }

  function readScheduleTime(key) {
    const hour = document.getElementById(`${key}Hour`).value;
    const minute = document.getElementById(`${key}Minute`).value;
    const period = document.getElementById(`${key}Period`).value;
    if (!hour && !minute && !period) return { time: null, complete: true };
    if (!hour || !minute || !period) return { time: null, complete: false };
    return { time: { hour, minute, period }, complete: true };
  }

  async function saveSchedule(event) {
    event.preventDefault();
    const fields = Object.keys(state.schedule).map(key => [key, readScheduleTime(key)]);
    const schedule = Object.fromEntries(fields.map(([key, result]) => [key, result.time]));
    const error = document.getElementById("scheduleError");
    if (fields.some(([, result]) => !result.complete)) {
      error.textContent = "Choose an hour, minute, and AM/PM for each time, or leave all three blank for an optional time.";
      error.hidden = false;
      return;
    }
    const timeRanges = [
      ["signInStart", "signInEnd", "Morning sign-in", true],
      ["signOutStart", "signOutEnd", "Morning sign-out", false],
      ["afternoonSignInStart", "afternoonSignInEnd", "Afternoon sign-in", false],
      ["afternoonSignOutStart", "afternoonSignOutEnd", "Afternoon sign-out", false]
    ];
    for (const [startKey, endKey, label, required] of timeRanges) {
      const start = schedule[startKey];
      const end = schedule[endKey];
      if (required && (!start || !end)) {
        error.textContent = `Set both start and end times for ${label}.`;
        error.hidden = false;
        return;
      }
      if (Boolean(start) !== Boolean(end) &&
        (startKey.startsWith("afternoon") || endKey.startsWith("afternoon"))) {
        error.textContent = `Set both start and end times for ${label}, or leave both blank.`;
        error.hidden = false;
        return;
      }
      if (start && end && timeInMinutes(start) >= timeInMinutes(end)) {
        error.textContent = `${label} end time must be later than its start time.`;
        error.hidden = false;
        return;
      }
    }
    const afternoonEnabled = Boolean(schedule.afternoonSignInStart || schedule.afternoonSignInEnd ||
      schedule.afternoonSignOutStart || schedule.afternoonSignOutEnd);
    if (afternoonEnabled && (!schedule.afternoonSignInStart || !schedule.afternoonSignInEnd ||
      !schedule.afternoonSignOutStart || !schedule.afternoonSignOutEnd ||
      !schedule.signOutStart || !schedule.signOutEnd)) {
      error.textContent = "Configure both afternoon periods and the morning sign-out period to enable all four regular attendance actions.";
      error.hidden = false;
      return;
    }

    try {
      const { error: saveError } = await supabaseClient.from("attendance_settings").upsert({
        id: 1,
        sign_in_start: scheduleTimeForDatabase(schedule.signInStart),
        sign_in_end: scheduleTimeForDatabase(schedule.signInEnd),
        sign_out_start: scheduleTimeForDatabase(schedule.signOutStart),
        sign_out_end: scheduleTimeForDatabase(schedule.signOutEnd),
        afternoon_sign_in_start: scheduleTimeForDatabase(schedule.afternoonSignInStart),
        afternoon_sign_in_end: scheduleTimeForDatabase(schedule.afternoonSignInEnd),
        afternoon_sign_out_start: scheduleTimeForDatabase(schedule.afternoonSignOutStart),
        afternoon_sign_out_end: scheduleTimeForDatabase(schedule.afternoonSignOutEnd)
      }, { onConflict: "id" });
      if (saveError) throw saveError;
      await reloadRemoteData();
      error.hidden = true;
      document.getElementById("scheduleSavedMessage").textContent = "Schedule saved successfully.";
      showToast("Attendance schedule saved successfully!");
    } catch (saveError) {
      console.error("Could not save attendance schedule to Supabase.", saveError);
      error.textContent = `Could not save schedule: ${saveError.message}`;
      error.hidden = false;
    }
  }

  async function createEvent(event) {
    event.preventDefault();
    const form = document.getElementById("eventForm");
    const errorElement = document.getElementById("eventError");
    const timeFields = [
      ["eventMorningSignInStart", "eventMorningSignInEnd", "Morning Sign In"],
      ["eventMorningSignOutStart", "eventMorningSignOutEnd", "Morning Sign Out"],
      ["eventAfternoonSignInStart", "eventAfternoonSignInEnd", "Afternoon Sign In"],
      ["eventAfternoonSignOutStart", "eventAfternoonSignOutEnd", "Afternoon Sign Out"]
    ];
    const parsedTimeFields = timeFields.map(([startKey, endKey, label]) => ({
      startKey,
      endKey,
      label,
      start: readScheduleTime(startKey),
      end: readScheduleTime(endKey)
    }));
    const incompletePeriod = parsedTimeFields.find(period =>
      !period.start.complete || !period.end.complete || !period.start.time || !period.end.time
    );
    if (incompletePeriod) {
      errorElement.textContent = `Choose an hour, minute, and AM/PM for both ${incompletePeriod.label} times.`;
      errorElement.hidden = false;
      return;
    }
    const invalidPeriod = parsedTimeFields.find(period =>
      timeInMinutes(period.start.time) >= timeInMinutes(period.end.time)
    );
    if (invalidPeriod) {
      errorElement.textContent = `${invalidPeriod.label} end time must be later than its start time.`;
      errorElement.hidden = false;
      return;
    }

    const eventId = document.getElementById("editingEventId").value;
    const payload = {
      name: document.getElementById("eventName").value.trim(),
      event_date: document.getElementById("eventDate").value,
      location: document.getElementById("eventLocation").value.trim(),
      enable_fines: document.getElementById("eventEnableFines").checked
    };
    if (!eventId) payload.is_active = false;
    timeFields.forEach(([startKey, endKey], index) => {
      const prefix = ["morning_sign_in", "morning_sign_out", "afternoon_sign_in", "afternoon_sign_out"][index];
      payload[`${prefix}_start`] = scheduleTimeForDatabase(readScheduleTime(startKey).time);
      payload[`${prefix}_end`] = scheduleTimeForDatabase(readScheduleTime(endKey).time);
    });

    try {
      const { error: saveError } = eventId
        ? await supabaseClient.from("events").update(payload).eq("id", eventId)
        : await supabaseClient.from("events").insert(payload);
      if (saveError) throw saveError;
      resetEventForm();
      errorElement.hidden = true;
      await reloadRemoteData();
      showToast(eventId ? "Event details updated." : "Event created. Set it active on the Events page to scan attendance.");
    } catch (saveError) {
      console.error("Could not create event in Supabase.", saveError);
      errorElement.textContent = `Could not create event: ${saveError.message}`;
      errorElement.hidden = false;
    }
  }

  function editEvent(eventId) {
    const event = state.events.find(item => item.id === eventId);
    if (!event) return;
    document.getElementById("editingEventId").value = event.id;
    document.getElementById("eventName").value = event.name;
    document.getElementById("eventDate").value = event.date;
    document.getElementById("eventLocation").value = event.location;
    document.getElementById("eventEnableFines").checked = event.enableFines;
    [
      ["eventMorningSignInStart", event.periods.morningSignIn[0]],
      ["eventMorningSignInEnd", event.periods.morningSignIn[1]],
      ["eventMorningSignOutStart", event.periods.morningSignOut[0]],
      ["eventMorningSignOutEnd", event.periods.morningSignOut[1]],
      ["eventAfternoonSignInStart", event.periods.afternoonSignIn[0]],
      ["eventAfternoonSignInEnd", event.periods.afternoonSignIn[1]],
      ["eventAfternoonSignOutStart", event.periods.afternoonSignOut[0]],
      ["eventAfternoonSignOutEnd", event.periods.afternoonSignOut[1]]
    ].forEach(([key, value]) => setScheduleTimeControls(key, value));
    document.getElementById("eventFormTitle").textContent = "Edit event";
    document.getElementById("saveEventButton").textContent = "Save Event";
    document.getElementById("cancelEventEdit").hidden = false;
    document.getElementById("eventError").hidden = true;
    document.getElementById("eventForm").scrollIntoView({ behavior: "smooth", block: "start" });
    document.getElementById("eventName").focus();
  }

  function resetEventForm() {
    document.getElementById("eventForm").reset();
    document.getElementById("editingEventId").value = "";
    document.getElementById("eventFormTitle").textContent = "Create event";
    document.getElementById("saveEventButton").textContent = "Create Event";
    document.getElementById("cancelEventEdit").hidden = true;
    document.getElementById("eventError").hidden = true;
  }

  async function setActiveEvent(eventId) {
    await stopQRScanner();
    try {
      const { error } = await supabaseClient.rpc("set_active_attendance_event", { p_event_id: eventId });
      if (error) throw error;
      await reloadRemoteData();
      showToast(eventId ? "Event selected as the active attendance session." : "Regular school attendance is now active.");
    } catch (error) {
      console.error("Could not change the active attendance session.", error);
      showToast(`Could not change attendance session: ${error.message}`, true);
    }
  }

  async function deleteEvent(eventId) {
    const event = state.events.find(item => item.id === eventId);
    if (!event) return;
    if (state.fines.some(fine => fine.event_id === eventId)) {
      showToast("This event has fine history and cannot be deleted.", true);
      return;
    }
    if (!window.confirm(`Delete "${event.name}"? Its event attendance records will also be deleted.`)) return;
    try {
      const { error } = await supabaseClient.from("events").delete().eq("id", eventId);
      if (error) throw error;
      await reloadRemoteData();
      showToast("Event deleted.");
    } catch (error) {
      console.error("Could not delete event from Supabase.", error);
      showToast(`Could not delete event: ${error.message}`, true);
    }
  }

  async function toggleFinePayment(fineId) {
    const fine = state.fines.find(item => item.id === fineId);
    if (!fine) return;
    const paymentStatus = fine.payment_status === "Paid" ? "Unpaid" : "Paid";
    try {
      const { error } = await supabaseClient.from("fines").update({ payment_status: paymentStatus }).eq("id", fineId);
      if (error) throw error;
      await reloadRemoteData();
    } catch (error) {
      console.error("Could not update fine payment status.", error);
      showToast(`Could not update payment status: ${error.message}`, true);
    }
  }

  async function finalizeMissedFines() {
    if (!supabaseClient || !signedInUser) return;
    const now = new Date();
    const localTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    try {
      const { error } = await supabaseClient.rpc("finalize_missed_event_fines", {
        p_attendance_date: toLocalDateInputValue(now),
        p_local_time: localTime
      });
      if (error) throw error;
      await reloadRemoteData();
    } catch (error) {
      console.error("Could not finalize missed event fines.", error);
      showToast(`Could not update event fines: ${error.message}`, true);
    }
  }

  let qrScanner = null;
  let qrLibraryPromise = null;
  let qrScannerRunning = false;
  let qrScannerStarting = false;
  let qrScannerStopping = false;
  let qrScanHandling = false;
  let qrLastRejectedText = "";
  let qrScanHintTimer = 0;
  let qrScannerStartPromise = null;
  let qrScannerCancelRequested = false;
  let qrCameraDevices = [];
  let qrActiveCameraId = "";
  let qrCameraSwitching = false;
  let qrCameraSwitchCancelRequested = false;

  async function loadQRScannerLibrary() {
    if (typeof window.Html5Qrcode === "function") return;
    if (qrLibraryPromise) return qrLibraryPromise;
    qrLibraryPromise = (async () => {
      const sources = [
        "https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js",
        "https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/html5-qrcode.min.js"
      ];
      let lastError;
      for (const source of sources) {
        try {
          await new Promise((resolve, reject) => {
            const script = document.createElement("script");
            const timeout = window.setTimeout(() => {
              script.remove();
              reject(new Error("Timed out loading the QR scanner library."));
            }, 12000);
            script.src = source;
            script.onload = () => {
              window.clearTimeout(timeout);
              if (typeof window.Html5Qrcode === "function") resolve();
              else reject(new Error("The QR scanner library loaded without its API."));
            };
            script.onerror = () => {
              window.clearTimeout(timeout);
              script.remove();
              reject(new Error(`Could not load QR scanner library from ${source}.`));
            };
            document.head.append(script);
          });
          return;
        } catch (error) {
          lastError = error;
          console.warn("QR scanner library source failed; trying the fallback.", error);
        }
      }
      throw lastError || new Error("No QR scanner library source could be loaded.");
    })().catch(error => {
      qrLibraryPromise = null;
      throw error;
    });
    return qrLibraryPromise;
  }

  function scannerCameraError(error) {
    const name = error && error.name;
    if (name === "OverconstrainedError" || name === "ConstraintNotSatisfiedError" || name === "CameraUnavailableError") {
      return "No compatible camera is available. Connect or enable a camera, then try again or use manual QR entry.";
    }
    if (!window.isSecureContext && location.hostname !== "localhost") {
      return "Camera access is blocked for this page. Open the system on localhost or HTTPS, or use manual QR entry.";
    }
    if (name === "NotAllowedError" || name === "PermissionDeniedError") {
      return "Camera permission was denied. Allow camera access in your browser settings, then try again.";
    }
    if (name === "SecurityError") {
      return "The browser blocked camera access. Check this page's camera permissions and try again.";
    }
    if (name === "NotFoundError" || name === "DevicesNotFoundError") {
      return "No camera was found on this device. Connect a camera or use manual QR entry.";
    }
    if (name === "NotReadableError" || name === "TrackStartError") {
      return "The camera is busy or unavailable. Close other camera apps and try again.";
    }
    return "The scanner could not start. Check camera permissions and try again, or use manual QR entry.";
  }

  function preferredCameraFacingMode() {
    const userAgent = navigator.userAgent || "";
    const tabletWithDesktopUserAgent = navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1;
    const isMobile = Boolean(navigator.userAgentData && navigator.userAgentData.mobile) ||
      /Android|iPhone|iPad|iPod|Mobile|Tablet/i.test(userAgent) || tabletWithDesktopUserAgent;
    return isMobile ? "environment" : "user";
  }

  function orderCameraDevices(cameras, facingMode) {
    const preferenceScore = camera => {
      const label = camera.label || "";
      if (facingMode === "environment") {
        if (/back|rear|environment|world/i.test(label)) return 3;
        if (/main|wide/i.test(label)) return 2;
        return 0;
      }
      if (/front|user|face/i.test(label)) return 3;
      if (/integrated|built[- ]?in|internal/i.test(label)) return 2;
      if (/webcam/i.test(label)) return 1;
      return 0;
    };
    return [...cameras].sort((a, b) => preferenceScore(b) - preferenceScore(a));
  }

  function activeCameraDescription(camera, trackSettings, facingMode) {
    const label = camera && camera.label && camera.label.trim();
    if (label && /back|rear|environment|world/i.test(label)) return `Back Camera — ${label}`;
    if (label && /front|user|face/i.test(label)) return `Front Camera — ${label}`;
    if (label) return label;
    const actualFacing = trackSettings && trackSettings.facingMode;
    if (actualFacing === "environment") return "Back Camera";
    if (actualFacing === "user") return "Front Camera";
    return facingMode === "environment" ? "Default mobile camera" : "Default computer camera";
  }

  function releaseScannerInstance(scanner) {
    if (!scanner) return Promise.resolve();
    const stop = scanner.isScanning ? scanner.stop().catch(error => {
      console.warn("Could not stop the QR scanner stream cleanly.", error);
    }) : Promise.resolve();
    return stop.then(() => scanner.clear()).catch(error => {
      console.warn("Could not release the QR scanner preview cleanly.", error);
    });
  }

  async function stopQRScanner(preserveCameraSwitch = false) {
    if (qrCameraSwitching && !preserveCameraSwitch) qrCameraSwitchCancelRequested = true;
    window.clearTimeout(qrScanHintTimer);
    if (qrScannerStarting) {
      qrScannerCancelRequested = true;
      if (qrScannerStartPromise) await qrScannerStartPromise;
    }
    if (!qrScanner || !qrScannerRunning) {
      document.getElementById("startQRScanner").hidden = false;
      document.getElementById("switchQRScannerCamera").hidden = true;
      document.getElementById("stopQRScanner").hidden = true;
      document.getElementById("qrCameraStatus").textContent = "Camera is stopped.";
      qrActiveCameraId = "";
      return;
    }
    qrScannerRunning = false;
    qrScannerStopping = true;
    document.getElementById("startQRScanner").hidden = false;
    document.getElementById("switchQRScannerCamera").hidden = true;
    document.getElementById("stopQRScanner").hidden = true;
    try {
      await releaseScannerInstance(qrScanner);
    } catch (error) {
      console.error("Could not stop the QR camera scanner.", error);
      setQRScanMessage("The camera scanner could not be stopped cleanly. You can continue using manual entry.", true);
    } finally {
      qrScannerStopping = false;
      qrScanner = null;
      qrActiveCameraId = "";
      document.getElementById("qrCameraStatus").textContent = "Camera is stopped.";
    }
  }

  async function handleQRDetection(decodedText) {
    if (qrScanHandling || qrScannerStopping) return;
    while (qrScannerStarting) {
      await new Promise(resolve => window.setTimeout(resolve, 50));
    }
    let student;
    try {
      student = studentForQR(decodedText);
    } catch (error) {
      if (qrLastRejectedText !== decodedText) {
        qrLastRejectedText = decodedText;
        setQRScanMessage(error.message, true);
      }
      return;
    }
    qrScanHandling = true;
    window.clearTimeout(qrScanHintTimer);
    setQRScanMessage(`QR code detected for ${student.name}. Processing attendance…`);
    await stopQRScanner();
    await recordQRAttendance(decodedText);
    qrScanHandling = false;
    qrLastRejectedText = "";
  }

  async function startQRScanner(cameraIdOverride = "", allowDuringCameraSwitch = false) {
    if (qrScannerStopping || qrScannerStarting || qrScannerRunning ||
      (qrCameraSwitching && !allowDuringCameraSwitch)) {
      setQRScanMessage("The camera is still closing. Please try again in a moment or use manual entry.", true);
      return;
    }
    const startButton = document.getElementById("startQRScanner");
    const switchCameraButton = document.getElementById("switchQRScannerCamera");
    const stopButton = document.getElementById("stopQRScanner");
    const cameraStatus = document.getElementById("qrCameraStatus");
    const facingMode = preferredCameraFacingMode();
    qrScannerStarting = true;
    qrScannerCancelRequested = false;
    startButton.hidden = true;
    startButton.disabled = true;
    startButton.textContent = "Loading scanner…";
    switchCameraButton.hidden = true;
    stopButton.hidden = true;
    setQRScanMessage(cameraIdOverride
      ? "Starting the selected camera…"
      : `Requesting access to the ${facingMode === "environment" ? "rear" : "front or default"} camera…`);
    qrScannerStartPromise = (async () => {
      try {
        await loadQRScannerLibrary();
        if (qrScannerCancelRequested) return;
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw Object.assign(new Error("Camera access requires HTTPS or localhost."), { name: "SecurityError" });
        }

        const scannerConfig = {
          fps: 12,
          qrbox: (viewfinderWidth, viewfinderHeight) => {
            const edge = Math.floor(Math.min(viewfinderWidth, viewfinderHeight) * 0.82);
            return { width: edge, height: edge };
          },
          aspectRatio: 1,
          disableFlip: false
        };
        const scannerOptions = { verbose: false };
        if (window.Html5QrcodeSupportedFormats) {
          scannerOptions.formatsToSupport = [window.Html5QrcodeSupportedFormats.QR_CODE];
        }

        const startCamera = async cameraConfig => {
          const scanner = new window.Html5Qrcode("qrReader", scannerOptions);
          qrScanner = scanner;
          try {
            await scanner.start(cameraConfig, scannerConfig, handleQRDetection, () => {});
            if (qrScannerCancelRequested) {
              throw Object.assign(new Error("Camera start was cancelled."), { name: "AbortError" });
            }
            const trackSettings = scanner.getRunningTrackSettings && scanner.getRunningTrackSettings();
            qrScannerRunning = true;
            const video = document.querySelector("#qrReader video");
            if (video) {
              video.setAttribute("playsinline", "");
              video.setAttribute("autoplay", "");
              video.setAttribute("muted", "");
              video.playsInline = true;
              video.autoplay = true;
              video.muted = true;
              await video.play().catch(error => {
                console.warn("The QR camera preview could not be explicitly resumed.", error);
              });
            }
            return {
              trackSettings,
              deviceId: typeof cameraConfig === "string"
                ? cameraConfig
                : trackSettings && trackSettings.deviceId || ""
            };
          } catch (error) {
            await releaseScannerInstance(scanner);
            if (qrScanner === scanner) qrScanner = null;
            qrScannerRunning = false;
            throw error;
          }
        };

        const permissionError = error =>
          ["NotAllowedError", "PermissionDeniedError", "SecurityError"].includes(error && error.name);
        let selectedCamera;
        let lastCameraError;
        if (cameraIdOverride) {
          selectedCamera = await startCamera(cameraIdOverride);
        } else {
          try {
            selectedCamera = await startCamera({ facingMode: { exact: facingMode } });
          } catch (exactError) {
            if (qrScannerCancelRequested) return;
            if (permissionError(exactError)) throw exactError;
            lastCameraError = exactError;
            try {
              selectedCamera = await startCamera({ facingMode });
            } catch (preferredError) {
              if (qrScannerCancelRequested) return;
              if (permissionError(preferredError)) throw preferredError;
              lastCameraError = preferredError;
              let cameras;
              try {
                cameras = await window.Html5Qrcode.getCameras();
              } catch (enumerationError) {
                if (permissionError(enumerationError)) throw enumerationError;
                console.warn("Could not enumerate cameras after the preferred camera request failed.", enumerationError);
                throw Object.assign(new Error("No compatible camera could be selected."), {
                  name: "CameraUnavailableError",
                  cause: lastCameraError
                });
              }
              qrCameraDevices = orderCameraDevices(cameras.filter(camera => camera.id), facingMode);
              for (const camera of qrCameraDevices) {
                if (qrScannerCancelRequested) return;
                try {
                  selectedCamera = await startCamera(camera.id);
                  break;
                } catch (cameraError) {
                  if (permissionError(cameraError)) throw cameraError;
                  lastCameraError = cameraError;
                }
              }
              if (!selectedCamera) {
                throw Object.assign(new Error("All available cameras failed to start."), {
                  name: "CameraUnavailableError",
                  cause: lastCameraError
                });
              }
            }
          }
        }

        if (qrScannerCancelRequested) return;
        if (!qrScannerRunning || !selectedCamera) {
          throw Object.assign(new Error("No camera is available."), { name: "CameraUnavailableError" });
        }

        qrActiveCameraId = selectedCamera.deviceId ||
          selectedCamera.trackSettings && selectedCamera.trackSettings.deviceId || "";
        try {
          const cameras = await window.Html5Qrcode.getCameras();
          qrCameraDevices = orderCameraDevices(cameras.filter(camera => camera.id), facingMode);
        } catch (enumerationError) {
          console.warn("Could not list cameras for the camera switch control.", enumerationError);
          qrCameraDevices = qrActiveCameraId ? [{ id: qrActiveCameraId, label: "" }] : [];
        }
        const activeCamera = qrCameraDevices.find(camera => camera.id === qrActiveCameraId);
        cameraStatus.textContent = `Currently using: ${activeCameraDescription(
          activeCamera,
          selectedCamera.trackSettings,
          facingMode
        )}`;
        switchCameraButton.hidden = false;
        switchCameraButton.disabled = qrCameraDevices.length < 2;
        switchCameraButton.title = qrCameraDevices.length < 2 ? "Only one camera is available." : "";
        setQRScanMessage("Scanning… QR code not detected yet. Hold the code steady inside the box.");
        stopButton.hidden = false;
        qrScanHintTimer = window.setTimeout(() => {
          if (qrScannerRunning && !qrScanHandling) {
            setQRScanMessage("Still scanning. Move the QR code into the box, improve lighting, or adjust the distance.");
          }
        }, 8000);
      } catch (error) {
        qrScannerRunning = false;
        startButton.hidden = false;
        switchCameraButton.hidden = true;
        stopButton.hidden = true;
        cameraStatus.textContent = "Camera is unavailable.";
        if (qrScanner) {
          await releaseScannerInstance(qrScanner);
          qrScanner = null;
        }
        qrActiveCameraId = "";
        if (qrScannerCancelRequested) return;
        console.error("Could not start the QR camera scanner.", error);
        setQRScanMessage(scannerCameraError(error), true);
      }
    })();
    try {
      await qrScannerStartPromise;
    } finally {
      qrScannerStarting = false;
      qrScannerStartPromise = null;
      qrScannerCancelRequested = false;
      startButton.disabled = false;
      startButton.textContent = "Start QR Scanner";
      if (!qrScannerRunning) startButton.hidden = false;
    }
    return qrScannerRunning;
  }

  async function switchQRScannerCamera() {
    if (qrCameraSwitching || qrScannerStarting || qrScannerStopping || !qrScannerRunning) return;
    const switchButton = document.getElementById("switchQRScannerCamera");
    const startButton = document.getElementById("startQRScanner");
    const facingMode = preferredCameraFacingMode();
    qrCameraSwitching = true;
    qrCameraSwitchCancelRequested = false;
    switchButton.disabled = true;
    startButton.disabled = true;
    try {
      let cameras;
      try {
        cameras = orderCameraDevices(
          (await window.Html5Qrcode.getCameras()).filter(camera => camera.id),
          facingMode
        );
      } catch (error) {
        console.error("Could not enumerate cameras for switching.", error);
        setQRScanMessage(scannerCameraError(error), true);
        return;
      }
      qrCameraDevices = cameras;
      if (cameras.length < 2) {
        switchButton.disabled = true;
        switchButton.title = "Only one camera is available.";
        setQRScanMessage("Only one camera is available on this device.");
        return;
      }

      const currentIndex = cameras.findIndex(camera => camera.id === qrActiveCameraId);
      const candidates = currentIndex < 0
        ? cameras
        : [...cameras.slice(currentIndex + 1), ...cameras.slice(0, currentIndex), cameras[currentIndex]];
      setQRScanMessage("Switching cameras…");
      await stopQRScanner(true);
      let started = false;
      for (const camera of candidates) {
        if (qrCameraSwitchCancelRequested) break;
        started = await startQRScanner(camera.id, true);
        if (started) break;
      }
      if (!started && !qrCameraSwitchCancelRequested) {
        setQRScanMessage("No available camera could be started. Check permissions or use manual QR entry.", true);
      }
    } finally {
      qrCameraSwitching = false;
      qrCameraSwitchCancelRequested = false;
      startButton.disabled = false;
      switchButton.disabled = qrCameraDevices.length < 2;
    }
  }

  async function deleteStudent(studentId) {
    const student = state.students.find(item => item.id === studentId);
    if (!student) return;
    const hasRecords = state.records.some(record => record.studentId === studentId);
    const message = hasRecords
      ? `Delete ${student.name} from the student directory? Their existing attendance records will be kept.`
      : `Delete ${student.name} from the student directory?`;
    if (!window.confirm(message)) return;
    try {
      const { error } = await supabaseClient.from("students").delete().eq("student_id", studentId);
      if (error) throw error;
      await reloadRemoteData();
      showToast(hasRecords ? "Student deleted successfully. Attendance history was kept." : "Student deleted successfully.");
    } catch (error) {
      console.error("Could not delete student from Supabase.", error);
      showToast(`Could not delete student: ${error.message}`, true);
    }
  }

  async function deleteRecord(studentId, date) {
    const record = recordFor(studentId, date);
    if (!record || !window.confirm(`Delete the ${record.status.toLowerCase()} record for ${record.name} on ${formatDate(date)}?`)) return;
    try {
      const { error } = await supabaseClient.from("attendance").delete()
        .eq("student_id", studentId)
        .eq("attendance_date", date);
      if (error) throw error;
      await reloadRemoteData();
      showToast("Attendance record deleted successfully.");
    } catch (error) {
      console.error("Could not delete attendance record from Supabase.", error);
      showToast(`Could not delete attendance: ${error.message}`, true);
    }
  }

  function showToast(message, isError = false) {
    const toast = elements.toast;
    toast.textContent = message;
    toast.classList.toggle("error", isError);
    toast.dataset.kind = isError ? "error" : "success";
    toast.classList.add("show");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("show"), 3200);
  }

  function closeMobileNav() {
    elements.sidebar.classList.remove("open");
    elements.mobileScrim.classList.remove("show");
    elements.menuToggle.setAttribute("aria-expanded", "false");
  }

  function showAuthenticationGate(message) {
    document.getElementById("authGate").hidden = false;
    document.querySelector(".app-shell").classList.remove("connected");
    if (message) {
      document.getElementById("authError").textContent = message;
      document.getElementById("authError").hidden = false;
    }
  }

  async function handleAuthenticationSubmit(event) {
    event.preventDefault();
    const errorElement = document.getElementById("authError");
    const submitButton = document.getElementById("authSubmit");
    errorElement.hidden = true;
    submitButton.disabled = true;
    submitButton.textContent = "Signing in…";
    try {
      const { error } = await supabaseClient.auth.signInWithPassword({
        email: document.getElementById("authEmail").value.trim(),
        password: document.getElementById("authPassword").value
      });
      if (error) throw error;
    } catch (error) {
      console.error("Supabase sign-in failed.", error);
      errorElement.textContent = error.message || "Sign-in failed. Check your account and try again.";
      errorElement.hidden = false;
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = "Sign in";
    }
  }

  async function handleAuthenticationState(session) {
    if (!session) {
      signedInUser = null;
      verifyingUserId = null;
      state.students = [];
      state.records = [];
      state.schedule = emptySchedule();
      state.events = [];
      state.fines = [];
      fineHistoryStudentId = null;
      if (fineHistoryDialog.open) fineHistoryDialog.close();
      if (realtimeChannel && supabaseClient) {
        await supabaseClient.removeChannel(realtimeChannel);
        realtimeChannel = null;
      }
      render();
      showAuthenticationGate();
      return;
    }
    if ((signedInUser && signedInUser.id === session.user.id) || verifyingUserId === session.user.id) return;
    verifyingUserId = session.user.id;
    let authorization;
    let authorizationError;
    try {
      const result = await supabaseClient
        .from("authorized_admins").select("user_id").eq("user_id", session.user.id).maybeSingle();
      authorization = result.data;
      authorizationError = result.error;
    } catch (error) {
      authorizationError = error;
    }
    if (authorizationError || !authorization) {
      verifyingUserId = null;
      if (authorizationError) console.error("Could not verify administrator authorization.", authorizationError);
      document.getElementById("authError").textContent = authorizationError
        ? `Could not verify account access: ${authorizationError.message}`
        : "This account is not authorized. Ask the Supabase project owner to approve it.";
      document.getElementById("authError").hidden = false;
      try {
        await supabaseClient.auth.signOut();
      } catch (error) {
        console.error("Could not end an unauthorized Supabase session.", error);
      }
      return;
    }
    verifyingUserId = null;
    signedInUser = session.user;
    document.getElementById("authGate").hidden = true;
    document.querySelector(".app-shell").classList.add("connected");
    document.getElementById("signedInEmail").textContent = session.user.email || "Administrator";
    document.getElementById("syncStatus").textContent = "Connecting…";
    await reloadRemoteData();
    subscribeToRemoteChanges();
  }

  function initializeSupabase() {
    const config = window.CC101_SUPABASE_CONFIG;
    const setupHint = document.getElementById("authSetupHint");
    if (!window.supabase || typeof window.supabase.createClient !== "function") {
      document.getElementById("authSubmit").disabled = true;
      setupHint.textContent = "Supabase client failed to load. Check your internet connection and reload.";
      return;
    }
    if (!config || !config.url || !config.anonKey ||
      config.url.includes("YOUR_PROJECT") || config.anonKey.includes("YOUR_SUPABASE")) {
      document.getElementById("authSubmit").disabled = true;
      setupHint.innerHTML = 'Add your Supabase project URL and anon key in supabase-config.js. Follow <a href="SUPABASE_SETUP.md">the setup guide</a>.';
      return;
    }
    try {
      supabaseClient = window.supabase.createClient(config.url, config.anonKey, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
      });
    } catch (error) {
      console.error("Supabase configuration is invalid.", error);
      document.getElementById("authSubmit").disabled = true;
      setupHint.textContent = `Supabase configuration is invalid: ${error.message}`;
      return;
    }
    setupHint.textContent = "Only authorized school administrator accounts can access shared student data.";
    supabaseClient.auth.onAuthStateChange((event, session) => {
      if (event === "SIGNED_OUT" || session) {
        window.setTimeout(() => handleAuthenticationState(session), 0);
      }
    });
    supabaseClient.auth.getSession().then(({ data, error }) => {
      if (error) {
        console.error("Could not restore Supabase session.", error);
        showAuthenticationGate(`Could not restore your sign-in: ${error.message}`);
        return;
      }
      handleAuthenticationState(data.session);
    }).catch(error => {
      console.error("Could not initialize Supabase authentication.", error);
      showAuthenticationGate(`Could not connect to Supabase: ${error.message}`);
    });
  }

  document.getElementById("authForm").addEventListener("submit", handleAuthenticationSubmit);
  document.getElementById("importLegacyData").addEventListener("click", importLegacyData);
  document.getElementById("signOutButton").addEventListener("click", async () => {
    if (!supabaseClient) return;
    try {
      const { error } = await supabaseClient.auth.signOut();
      if (error) throw error;
    } catch (error) {
      console.error("Could not sign out from Supabase.", error);
      showToast(`Could not sign out: ${error.message}`, true);
    }
  });

  document.addEventListener("click", event => {
    const nav = event.target.closest("[data-page]");
    if (nav) {
      showPage(nav.dataset.page);
      return;
    }
    const go = event.target.closest("[data-go]");
    if (go) {
      showPage(go.dataset.go);
      return;
    }
    const action = event.target.closest("[data-action]");
    if (!action) return;
    switch (action.dataset.action) {
      case "add-student":
        openStudentDialog();
        break;
      case "edit-student": {
        const student = state.students.find(item => item.id === action.dataset.id);
        if (student) openStudentDialog(student);
        break;
      }
      case "view-qr": {
        const student = state.students.find(item => item.id === action.dataset.id);
        if (student) openStudentQRCode(student);
        break;
      }
      case "delete-student":
        deleteStudent(action.dataset.id);
        break;
      case "delete-record":
        deleteRecord(action.dataset.id, action.dataset.date);
        break;
      case "mark-attendance":
        markAttendance(action.dataset.id, action.dataset.status, document.getElementById("attendanceDate").value);
        break;
      case "edit-event":
        editEvent(action.dataset.id);
        break;
      case "activate-event":
        setActiveEvent(action.dataset.id);
        break;
      case "deactivate-event":
        setActiveEvent(null);
        break;
      case "delete-event":
        deleteEvent(action.dataset.id);
        break;
      case "toggle-fine-payment":
        toggleFinePayment(action.dataset.id);
        break;
      case "view-fine-history":
        openFineHistory(action.dataset.id);
        break;
    }
  });

  elements.form.addEventListener("submit", handleStudentSubmit);
  document.getElementById("scheduleForm").addEventListener("submit", saveSchedule);
  document.getElementById("eventForm").addEventListener("submit", createEvent);
  document.getElementById("cancelEventEdit").addEventListener("click", resetEventForm);
  document.getElementById("activeSessionSelect").addEventListener("change", event => {
    setActiveEvent(event.target.value === "regular" ? null : event.target.value);
  });
  elements.qrDialog = document.getElementById("qrDialog");
  document.querySelectorAll(".close-qr-dialog").forEach(button => button.addEventListener("click", () => elements.qrDialog.close()));
  elements.qrDialog.addEventListener("click", event => {
    if (event.target === elements.qrDialog) elements.qrDialog.close();
  });
  const fineHistoryDialog = document.getElementById("fineHistoryDialog");
  document.querySelectorAll(".close-fine-history").forEach(button =>
    button.addEventListener("click", () => fineHistoryDialog.close())
  );
  fineHistoryDialog.addEventListener("click", event => {
    if (event.target === fineHistoryDialog) fineHistoryDialog.close();
  });
  document.getElementById("fineHistoryEventFilter").addEventListener("change", renderFineHistory);
  document.getElementById("fineHistoryDateFilter").addEventListener("change", renderFineHistory);
  document.getElementById("fineHistoryPaymentFilter").addEventListener("change", renderFineHistory);
  document.getElementById("fineSearch").addEventListener("input", renderFines);
  document.getElementById("downloadQRCode").addEventListener("click", () => {
    const code = document.querySelector("#studentQRCode canvas, #studentQRCode img");
    if (!code) {
      document.getElementById("qrLibraryNotice").hidden = false;
      return;
    }
    const link = document.createElement("a");
    link.download = `${document.getElementById("qrStudentId").textContent.replace("Student ID: ", "")}-qr.png`;
    link.href = code.tagName === "CANVAS" ? code.toDataURL("image/png") : code.src;
    link.click();
  });
  document.getElementById("copyQRCodeValue").addEventListener("click", async event => {
    const value = event.currentTarget.dataset.payload;
    if (!value) {
      showToast("Open a student QR code first to copy its value.", true);
      return;
    }
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(value);
      } else {
        const temporaryInput = document.createElement("textarea");
        temporaryInput.value = value;
        temporaryInput.setAttribute("readonly", "");
        temporaryInput.style.position = "fixed";
        temporaryInput.style.opacity = "0";
        document.body.append(temporaryInput);
        temporaryInput.select();
        const copied = document.execCommand("copy");
        temporaryInput.remove();
        if (!copied) throw new Error("Clipboard access is unavailable.");
      }
      showToast("QR value copied. Paste it into the manual test field.");
    } catch (error) {
      console.error("Could not copy the student QR value.", error);
      showToast("Could not copy the QR value. Select the displayed value and copy it manually.", true);
    }
  });
  document.getElementById("printQRCode").addEventListener("click", () => window.print());
  document.getElementById("qrManualForm").addEventListener("submit", event => {
    event.preventDefault();
    recordQRAttendance(document.getElementById("qrManualInput").value);
    document.getElementById("qrManualInput").select();
  });
  document.getElementById("startQRScanner").addEventListener("click", startQRScanner);
  document.getElementById("switchQRScannerCamera").addEventListener("click", switchQRScannerCamera);
  document.getElementById("stopQRScanner").addEventListener("click", stopQRScanner);
  document.getElementById("qrAttendanceDate").addEventListener("change", () => {
    stopQRScanner();
    renderActiveSession();
  });
  document.getElementById("courseTrigger").addEventListener("click", () => {
    if (document.getElementById("courseMenu").classList.contains("open")) closeCourseMenu();
    else openCourseMenu();
  });
  document.getElementById("courseSearch").addEventListener("input", event => renderCourseOptions(event.target.value));
  document.getElementById("courseOptions").addEventListener("click", event => {
    const option = event.target.closest("[data-course]");
    if (!option) return;
    document.getElementById("studentCourse").value = option.dataset.course;
    document.getElementById("courseSelectedLabel").textContent = option.dataset.course;
    renderCourseOptions(document.getElementById("courseSearch").value);
    closeCourseMenu();
    document.getElementById("courseTrigger").focus();
  });
  document.getElementById("courseSearch").addEventListener("keydown", event => {
    if (event.key === "Escape") {
      closeCourseMenu();
      document.getElementById("courseTrigger").focus();
    }
    if (event.key === "ArrowDown") {
      const firstOption = document.querySelector("#courseOptions [role='option']");
      if (firstOption) {
        event.preventDefault();
        firstOption.focus();
      }
    }
  });
  document.getElementById("courseOptions").addEventListener("keydown", event => {
    const options = Array.from(document.querySelectorAll("#courseOptions [role='option']"));
    const currentIndex = options.indexOf(event.target);
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      const direction = event.key === "ArrowDown" ? 1 : -1;
      const nextOption = options[(currentIndex + direction + options.length) % options.length];
      if (nextOption) nextOption.focus();
    } else if (event.key === "Escape") {
      closeCourseMenu();
      document.getElementById("courseTrigger").focus();
    }
  });
  document.addEventListener("click", event => {
    if (!event.target.closest(".course-field")) closeCourseMenu();
  });
  document.querySelectorAll(".time-picker select[id$='Minute']").forEach(select => {
    select.options.length = 1;
    for (let minute = 0; minute < 60; minute += 5) {
      const option = document.createElement("option");
      option.value = String(minute).padStart(2, "0");
      option.textContent = option.value;
      select.append(option);
    }
  });
  renderCourseOptions("");
  document.querySelectorAll(".close-dialog").forEach(button => button.addEventListener("click", () => elements.dialog.close()));
  elements.dialog.addEventListener("click", event => {
    if (event.target === elements.dialog) elements.dialog.close();
  });
  document.getElementById("studentSearch").addEventListener("input", renderStudents);
  document.getElementById("recordSearch").addEventListener("input", renderRecords);
  document.getElementById("statusFilter").addEventListener("change", renderRecords);
  document.getElementById("attendanceDate").addEventListener("change", event => {
    if (!event.target.value) event.target.value = today;
    renderAttendance();
  });
  document.getElementById("markAllPresent").addEventListener("click", async () => {
    const date = document.getElementById("attendanceDate").value;
    try {
      const attendanceRows = state.students.map(student => {
        const existing = recordFor(student.id, date);
        return {
          ...databaseStudentPayload(student),
          attendance_date: date,
          time_in: existing ? existing.timeInRaw : null,
          time_out: existing ? existing.timeOutRaw : null,
          status: "Present"
        };
      });
      const { error } = await supabaseClient.from("attendance").upsert(attendanceRows, {
        onConflict: "student_id,attendance_date"
      });
      if (error) throw error;
      await reloadRemoteData();
      showToast("Attendance saved successfully for the whole class!");
    } catch (error) {
      console.error("Could not mark all students present in Supabase.", error);
      showToast(`Could not save attendance: ${error.message}`, true);
    }
  });
  elements.menuToggle.addEventListener("click", () => {
    const open = !elements.sidebar.classList.contains("open");
    elements.sidebar.classList.toggle("open", open);
    elements.mobileScrim.classList.toggle("show", open);
    elements.menuToggle.setAttribute("aria-expanded", String(open));
  });
  elements.mobileScrim.addEventListener("click", closeMobileNav);
  document.addEventListener("pointerdown", event => {
    if (reducedMotion.matches) return;
    const button = event.target.closest("button");
    if (!button || button.disabled) return;
    const bounds = button.getBoundingClientRect();
    const ripple = document.createElement("span");
    const diameter = Math.max(bounds.width, bounds.height) * 1.5;
    ripple.className = "ripple";
    ripple.style.width = `${diameter}px`;
    ripple.style.height = `${diameter}px`;
    ripple.style.left = `${event.clientX - bounds.left - diameter / 2}px`;
    ripple.style.top = `${event.clientY - bounds.top - diameter / 2}px`;
    button.append(ripple);
    ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
  });
  document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
      event.preventDefault();
      const activePage = document.querySelector(".page.active");
      if (activePage.id === "page-students") document.getElementById("studentSearch").focus();
      else if (activePage.id === "page-records") document.getElementById("recordSearch").focus();
      else {
        showPage("students");
        document.getElementById("studentSearch").focus();
      }
    }
  });

  document.getElementById("attendanceDate").value = today;
  document.getElementById("qrAttendanceDate").value = today;
  render();
  window.setInterval(() => {
    const finesPageOpen = document.getElementById("page-fines").classList.contains("active");
    const activeFinedEvent = state.events.some(event => event.active && event.enableFines);
    const scannerPageOpen = document.getElementById("page-qr-attendance").classList.contains("active");
    if (finesPageOpen || (scannerPageOpen && activeFinedEvent)) finalizeMissedFines();
  }, 60000);
  document.querySelectorAll(".page.active").forEach(page => page.classList.add("page-enter"));
  initializeSupabase();
})();
