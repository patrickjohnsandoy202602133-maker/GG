create extension if not exists pgcrypto;

create table if not exists public.authorized_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_id text not null,
  full_name text not null,
  course text not null,
  year_level text not null check (year_level in ('1st Year', '2nd Year', '3rd Year', '4th Year')),
  section text not null check (section in ('A', 'B')),
  created_at timestamptz not null default now()
);

create unique index if not exists students_student_id_unique
  on public.students (upper(regexp_replace(btrim(student_id), '[[:space:]]', '', 'g')));

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id text not null,
  attendance_date date not null,
  time_in timestamptz,
  time_out timestamptz,
  status text not null check (status in ('Present', 'Late', 'Absent')),
  full_name text not null,
  course text not null,
  year_level text not null,
  section text not null,
  created_at timestamptz not null default now(),
  constraint attendance_student_date_unique unique (student_id, attendance_date)
);

create table if not exists public.attendance_settings (
  id integer primary key check (id = 1),
  sign_in_start time,
  sign_in_end time,
  sign_out_start time,
  sign_out_end time,
  updated_at timestamptz not null default now()
);

insert into public.attendance_settings (id)
values (1)
on conflict (id) do nothing;

alter table public.authorized_admins enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.attendance_settings enable row level security;

drop policy if exists "Admins can view their authorization" on public.authorized_admins;
create policy "Admins can view their authorization"
  on public.authorized_admins for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "Authorized admins manage students" on public.students;
create policy "Authorized admins manage students"
  on public.students for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage attendance" on public.attendance;
create policy "Authorized admins manage attendance"
  on public.attendance for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage attendance settings" on public.attendance_settings;
create policy "Authorized admins manage attendance settings"
  on public.attendance_settings for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

grant select on public.authorized_admins to authenticated;
grant select, insert, update, delete on public.students to authenticated;
grant select, insert, update, delete on public.attendance to authenticated;
grant select, insert, update, delete on public.attendance_settings to authenticated;

create or replace function public.save_student(
  p_original_student_id text,
  p_student_id text,
  p_full_name text,
  p_course text,
  p_year_level text,
  p_section text
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    raise exception 'Administrator authorization required.';
  end if;

  if nullif(btrim(p_student_id), '') is null
    or nullif(btrim(p_full_name), '') is null
    or nullif(btrim(p_course), '') is null
    or p_year_level is null
    or p_year_level not in ('1st Year', '2nd Year', '3rd Year', '4th Year')
    or p_section is null
    or p_section not in ('A', 'B') then
    raise exception 'Student details are incomplete or invalid.';
  end if;

  if p_original_student_id is null then
    insert into public.students (student_id, full_name, course, year_level, section)
    values (btrim(p_student_id), btrim(p_full_name), btrim(p_course), p_year_level, p_section);
    return;
  end if;

  update public.students
  set student_id = btrim(p_student_id),
      full_name = btrim(p_full_name),
      course = btrim(p_course),
      year_level = p_year_level,
      section = p_section
  where student_id = p_original_student_id;
  if not found then
    raise exception 'Student not found.';
  end if;

  update public.attendance
  set student_id = btrim(p_student_id),
      full_name = btrim(p_full_name),
      course = btrim(p_course),
      year_level = p_year_level,
      section = p_section
  where student_id = p_original_student_id;
end;
$$;

create or replace function public.scan_attendance(
  p_qr_value text,
  p_attendance_date date,
  p_local_time time,
  p_scanned_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_student public.students%rowtype;
  v_record public.attendance%rowtype;
  v_schedule public.attendance_settings%rowtype;
  v_student_id text;
  v_qr text;
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    return jsonb_build_object('result', 'auth_required');
  end if;

  if p_qr_value is null or p_attendance_date is null or p_local_time is null or p_scanned_at is null then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  v_qr := upper(regexp_replace(btrim(p_qr_value), '[[:space:]]', '', 'g'));
  if left(v_qr, 6) = 'CC101|' then
    v_student_id := substring(v_qr from 7);
  elsif left(v_qr, 1) = '{' then
    begin
      v_student_id := upper(regexp_replace(btrim((p_qr_value::jsonb ->> 'studentId')), '[[:space:]]', '', 'g'));
    exception when others then
      return jsonb_build_object('result', 'invalid_qr');
    end;
  elsif position('|' in v_qr) = 0 then
    v_student_id := v_qr;
  else
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  if v_student_id = '' then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_student
  from public.students s
  where upper(regexp_replace(btrim(s.student_id), '[[:space:]]', '', 'g')) = v_student_id
  limit 1;
  if not found then
    return jsonb_build_object('result', 'student_not_found');
  end if;

  select * into v_schedule
  from public.attendance_settings
  where id = 1;
  if not found or v_schedule.sign_in_start is null or v_schedule.sign_in_end is null then
    return jsonb_build_object('result', 'schedule_not_configured');
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_student.student_id || ':' || p_attendance_date::text, 0));
  select * into v_record
  from public.attendance a
  where a.student_id = v_student.student_id and a.attendance_date = p_attendance_date
  for update;

  if found and v_record.time_in is not null and v_record.time_out is not null then
    return jsonb_build_object(
      'result', 'already_complete',
      'full_name', v_student.full_name,
      'student_id', v_student.student_id
    );
  end if;

  if found and v_record.time_in is not null then
    if v_schedule.sign_out_start is not null and p_local_time < v_schedule.sign_out_start then
      return jsonb_build_object('result', 'sign_out_not_open', 'full_name', v_student.full_name);
    end if;
    if v_schedule.sign_out_end is not null and p_local_time > v_schedule.sign_out_end then
      return jsonb_build_object('result', 'sign_out_closed', 'full_name', v_student.full_name);
    end if;

    update public.attendance
    set time_out = p_scanned_at,
        full_name = v_student.full_name,
        course = v_student.course,
        year_level = v_student.year_level,
        section = v_student.section
    where id = v_record.id;
    return jsonb_build_object(
      'result', 'signed_out',
      'student_id', v_student.student_id,
      'full_name', v_student.full_name,
      'course', v_student.course,
      'year_level', v_student.year_level,
      'section', v_student.section
    );
  end if;

  if p_local_time < v_schedule.sign_in_start then
    return jsonb_build_object('result', 'sign_in_not_open');
  end if;
  if p_local_time > v_schedule.sign_in_end then
    return jsonb_build_object('result', 'sign_in_closed');
  end if;

  insert into public.attendance (
    student_id, attendance_date, time_in, status, full_name, course, year_level, section
  ) values (
    v_student.student_id, p_attendance_date, p_scanned_at, 'Present',
    v_student.full_name, v_student.course, v_student.year_level, v_student.section
  )
  on conflict (student_id, attendance_date) do update
  set time_in = excluded.time_in,
      time_out = null,
      status = 'Present',
      full_name = excluded.full_name,
      course = excluded.course,
      year_level = excluded.year_level,
      section = excluded.section
  where public.attendance.time_in is null;

  return jsonb_build_object(
    'result', 'signed_in',
    'student_id', v_student.student_id,
    'full_name', v_student.full_name,
    'course', v_student.course,
    'year_level', v_student.year_level,
    'section', v_student.section
  );
end;
$$;

revoke all on function public.scan_attendance(text, date, time, timestamptz) from public, anon;
grant execute on function public.scan_attendance(text, date, time, timestamptz) to authenticated;
revoke all on function public.save_student(text, text, text, text, text, text) from public, anon;
grant execute on function public.save_student(text, text, text, text, text, text) to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'students'
  ) then
    alter publication supabase_realtime add table public.students;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'attendance'
  ) then
    alter publication supabase_realtime add table public.attendance;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'attendance_settings'
  ) then
    alter publication supabase_realtime add table public.attendance_settings;
  end if;
end
$$;

alter table public.attendance_settings
  add column if not exists afternoon_sign_in_start time,
  add column if not exists afternoon_sign_in_end time,
  add column if not exists afternoon_sign_out_start time,
  add column if not exists afternoon_sign_out_end time;

alter table public.attendance
  add column if not exists morning_sign_in timestamptz,
  add column if not exists morning_sign_out timestamptz,
  add column if not exists afternoon_sign_in timestamptz,
  add column if not exists afternoon_sign_out timestamptz;

update public.attendance
set morning_sign_in = coalesce(morning_sign_in, time_in),
    morning_sign_out = coalesce(morning_sign_out, time_out)
where morning_sign_in is null or morning_sign_out is null;

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  event_date date not null,
  location text not null,
  enable_fines boolean not null default false,
  morning_sign_in_start time not null,
  morning_sign_in_end time not null,
  morning_sign_out_start time not null,
  morning_sign_out_end time not null,
  afternoon_sign_in_start time not null,
  afternoon_sign_in_end time not null,
  afternoon_sign_out_start time not null,
  afternoon_sign_out_end time not null,
  is_active boolean not null default false,
  created_at timestamptz not null default now(),
  constraint events_morning_sign_in_range check (morning_sign_in_start <= morning_sign_in_end),
  constraint events_morning_sign_out_range check (morning_sign_out_start <= morning_sign_out_end),
  constraint events_afternoon_sign_in_range check (afternoon_sign_in_start <= afternoon_sign_in_end),
  constraint events_afternoon_sign_out_range check (afternoon_sign_out_start <= afternoon_sign_out_end)
);

create unique index if not exists events_single_active_unique
  on public.events (is_active) where is_active;

create table if not exists public.event_attendance (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  student_id text not null,
  full_name text not null,
  course text not null,
  year_level text not null,
  section text not null,
  morning_sign_in timestamptz,
  morning_sign_out timestamptz,
  afternoon_sign_in timestamptz,
  afternoon_sign_out timestamptz,
  created_at timestamptz not null default now(),
  constraint event_attendance_event_student_unique unique (event_id, student_id)
);

create table if not exists public.fines (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete restrict,
  student_id text not null,
  full_name text not null,
  course text not null,
  year_level text not null,
  section text not null,
  event_name text not null,
  event_date date not null,
  missed_action text not null check (missed_action in (
    'Morning Sign In', 'Morning Sign Out', 'Afternoon Sign In', 'Afternoon Sign Out'
  )),
  reason text not null,
  amount numeric(8, 2) not null default 25 check (amount = 25),
  payment_status text not null default 'Unpaid' check (payment_status in ('Unpaid', 'Paid')),
  created_at timestamptz not null default now(),
  constraint fines_event_student_action_unique unique (event_id, student_id, missed_action)
);

alter table public.fines
  add column if not exists course text,
  add column if not exists year_level text,
  add column if not exists section text,
  add column if not exists reason text;

update public.fines f
set course = coalesce(f.course, ea.course, s.course, 'Not recorded'),
    year_level = coalesce(f.year_level, ea.year_level, s.year_level, 'Not recorded'),
    section = coalesce(f.section, ea.section, s.section, 'Not recorded'),
    reason = coalesce(f.reason, 'Did not scan during ' || f.missed_action)
from public.event_attendance ea
left join public.students s on s.student_id = ea.student_id
where ea.event_id = f.event_id and ea.student_id = f.student_id;

update public.fines
set course = coalesce(course, 'Not recorded'),
    year_level = coalesce(year_level, 'Not recorded'),
    section = coalesce(section, 'Not recorded'),
    reason = coalesce(reason, 'Did not scan during ' || missed_action)
where course is null or year_level is null or section is null or reason is null;

alter table public.fines
  alter column course set not null,
  alter column year_level set not null,
  alter column section set not null,
  alter column reason set not null;

alter table public.fines drop constraint if exists fines_event_id_fkey;
alter table public.fines
  add constraint fines_event_id_fkey
  foreign key (event_id) references public.events(id) on delete restrict;

alter table public.events enable row level security;
alter table public.event_attendance enable row level security;
alter table public.fines enable row level security;

drop policy if exists "Authorized admins manage events" on public.events;
create policy "Authorized admins manage events"
  on public.events for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage event attendance" on public.event_attendance;
create policy "Authorized admins manage event attendance"
  on public.event_attendance for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage fines" on public.fines;
drop policy if exists "Authorized admins view fines" on public.fines;
create policy "Authorized admins view fines"
  on public.fines for select to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins update fine payment" on public.fines;
create policy "Authorized admins update fine payment"
  on public.fines for update to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

grant select, insert, update, delete on public.events to authenticated;
grant select, insert, update, delete on public.event_attendance to authenticated;
revoke all on public.fines from authenticated;
grant select on public.fines to authenticated;
grant update (payment_status) on public.fines to authenticated;

create or replace function public.set_active_attendance_event(p_event_id uuid)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    raise exception 'Administrator authorization required.';
  end if;
  if p_event_id is not null and not exists (
    select 1 from public.events where id = p_event_id
  ) then
    raise exception 'Event not found.';
  end if;

  update public.events set is_active = false where is_active;
  if p_event_id is not null then
    update public.events set is_active = true where id = p_event_id;
  end if;
end;
$$;

create or replace function public.finalize_missed_event_fines(
  p_attendance_date date,
  p_local_time time
)
returns integer
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_inserted integer;
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    raise exception 'Administrator authorization required.';
  end if;
  if p_attendance_date is null or p_local_time is null then
    raise exception 'Local attendance date and time are required.';
  end if;

  insert into public.event_attendance (event_id, student_id, full_name, course, year_level, section)
  select e.id, s.student_id, s.full_name, s.course, s.year_level, s.section
  from public.events e
  cross join public.students s
  where e.enable_fines and e.event_date <= p_attendance_date
  on conflict (event_id, student_id) do nothing;

  insert into public.fines (
    event_id, student_id, full_name, course, year_level, section, event_name, event_date,
    missed_action, reason, amount
  )
  select e.id, ea.student_id, ea.full_name, ea.course, ea.year_level, ea.section,
    e.name, e.event_date, due.action_name,
    'Did not scan during ' || due.action_name, 25
  from public.events e
  join public.event_attendance ea on ea.event_id = e.id
  cross join lateral (values
    ('Morning Sign In', e.morning_sign_in_end, ea.morning_sign_in),
    ('Morning Sign Out', e.morning_sign_out_end, ea.morning_sign_out),
    ('Afternoon Sign In', e.afternoon_sign_in_end, ea.afternoon_sign_in),
    ('Afternoon Sign Out', e.afternoon_sign_out_end, ea.afternoon_sign_out)
  ) as due(action_name, period_end, scanned_at)
  where e.enable_fines
    and e.event_date <= p_attendance_date
    and due.scanned_at is null
    and (e.event_date < p_attendance_date or due.period_end < p_local_time)
  on conflict (event_id, student_id, missed_action) do nothing;

  get diagnostics v_inserted = row_count;
  return v_inserted;
end;
$$;

create or replace function public.scan_regular_four_period(
  p_qr_value text,
  p_attendance_date date,
  p_local_time time,
  p_scanned_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_student public.students%rowtype;
  v_record public.attendance%rowtype;
  v_schedule public.attendance_settings%rowtype;
  v_student_id text;
  v_qr text;
  v_action text;
  v_action_column text;
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    return jsonb_build_object('result', 'auth_required');
  end if;
  if p_qr_value is null or p_attendance_date is null or p_local_time is null or p_scanned_at is null then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_schedule from public.attendance_settings where id = 1;
  if v_schedule.afternoon_sign_in_start is null and v_schedule.afternoon_sign_in_end is null
    and v_schedule.afternoon_sign_out_start is null and v_schedule.afternoon_sign_out_end is null then
    return public.scan_attendance(p_qr_value, p_attendance_date, p_local_time, p_scanned_at);
  end if;
  if v_schedule.afternoon_sign_in_start is null or v_schedule.afternoon_sign_in_end is null
    or v_schedule.afternoon_sign_out_start is null or v_schedule.afternoon_sign_out_end is null then
    return jsonb_build_object('result', 'schedule_not_configured');
  end if;
  if v_schedule.sign_in_start is null or v_schedule.sign_in_end is null
    or v_schedule.sign_out_start is null or v_schedule.sign_out_end is null then
    return jsonb_build_object('result', 'schedule_not_configured');
  end if;

  v_qr := upper(regexp_replace(btrim(p_qr_value), '[[:space:]]', '', 'g'));
  if left(v_qr, 6) = 'CC101|' then
    v_student_id := substring(v_qr from 7);
  elsif left(v_qr, 1) = '{' then
    begin
      v_student_id := upper(regexp_replace(btrim((p_qr_value::jsonb ->> 'studentId')), '[[:space:]]', '', 'g'));
    exception when others then
      return jsonb_build_object('result', 'invalid_qr');
    end;
  elsif position('|' in v_qr) = 0 then
    v_student_id := v_qr;
  else
    return jsonb_build_object('result', 'invalid_qr');
  end if;
  if v_student_id = '' then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_student
  from public.students s
  where upper(regexp_replace(btrim(s.student_id), '[[:space:]]', '', 'g')) = v_student_id
  limit 1;
  if not found then
    return jsonb_build_object('result', 'student_not_found');
  end if;

  if p_local_time between v_schedule.sign_in_start and v_schedule.sign_in_end then
    v_action := 'Morning Sign In'; v_action_column := 'morning_sign_in';
  elsif p_local_time between v_schedule.sign_out_start and v_schedule.sign_out_end then
    v_action := 'Morning Sign Out'; v_action_column := 'morning_sign_out';
  elsif p_local_time between v_schedule.afternoon_sign_in_start and v_schedule.afternoon_sign_in_end then
    v_action := 'Afternoon Sign In'; v_action_column := 'afternoon_sign_in';
  elsif p_local_time between v_schedule.afternoon_sign_out_start and v_schedule.afternoon_sign_out_end then
    v_action := 'Afternoon Sign Out'; v_action_column := 'afternoon_sign_out';
  else
    return jsonb_build_object('result', 'regular_period_not_open', 'full_name', v_student.full_name);
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_student.student_id || ':' || p_attendance_date::text, 0));
  insert into public.attendance (
    student_id, attendance_date, time_in, time_out, status, full_name, course, year_level, section,
    morning_sign_in, morning_sign_out, afternoon_sign_in, afternoon_sign_out
  ) values (
    v_student.student_id, p_attendance_date, null, null,
    'Present', v_student.full_name, v_student.course, v_student.year_level, v_student.section,
    null, null, null, null
  ) on conflict (student_id, attendance_date) do nothing;

  select * into v_record from public.attendance
  where student_id = v_student.student_id and attendance_date = p_attendance_date
  for update;
  if (v_action_column = 'morning_sign_in' and v_record.morning_sign_in is not null)
    or (v_action_column = 'morning_sign_out' and v_record.morning_sign_out is not null)
    or (v_action_column = 'afternoon_sign_in' and v_record.afternoon_sign_in is not null)
    or (v_action_column = 'afternoon_sign_out' and v_record.afternoon_sign_out is not null) then
    return jsonb_build_object('result', 'regular_action_already_recorded', 'full_name', v_student.full_name, 'action', v_action);
  end if;

  update public.attendance set
    time_in = case when v_action_column in ('morning_sign_in', 'afternoon_sign_in')
      then coalesce(time_in, p_scanned_at) else time_in end,
    time_out = case when v_action_column in ('morning_sign_out', 'afternoon_sign_out')
      then p_scanned_at else time_out end,
    status = 'Present',
    full_name = v_student.full_name,
    course = v_student.course,
    year_level = v_student.year_level,
    section = v_student.section,
    morning_sign_in = case when v_action_column = 'morning_sign_in' then p_scanned_at else morning_sign_in end,
    morning_sign_out = case when v_action_column = 'morning_sign_out' then p_scanned_at else morning_sign_out end,
    afternoon_sign_in = case when v_action_column = 'afternoon_sign_in' then p_scanned_at else afternoon_sign_in end,
    afternoon_sign_out = case when v_action_column = 'afternoon_sign_out' then p_scanned_at else afternoon_sign_out end
  where id = v_record.id;

  return jsonb_build_object(
    'result', 'regular_action_signed',
    'full_name', v_student.full_name,
    'student_id', v_student.student_id,
    'course', v_student.course,
    'year_level', v_student.year_level,
    'section', v_student.section,
    'action', v_action
  );
end;
$$;

create or replace function public.scan_attendance_session(
  p_qr_value text,
  p_attendance_date date,
  p_local_time time,
  p_scanned_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_event public.events%rowtype;
  v_student public.students%rowtype;
  v_attendance public.event_attendance%rowtype;
  v_student_id text;
  v_qr text;
  v_action text;
  v_action_column text;
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    return jsonb_build_object('result', 'auth_required');
  end if;
  if p_qr_value is null or p_attendance_date is null or p_local_time is null or p_scanned_at is null then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_event from public.events where is_active limit 1;
  if not found then
    return public.scan_regular_four_period(p_qr_value, p_attendance_date, p_local_time, p_scanned_at);
  end if;
  if v_event.event_date <> p_attendance_date then
    return jsonb_build_object('result', 'event_date_mismatch', 'event_name', v_event.name, 'event_date', v_event.event_date);
  end if;

  v_qr := upper(regexp_replace(btrim(p_qr_value), '[[:space:]]', '', 'g'));
  if left(v_qr, 6) = 'CC101|' then
    v_student_id := substring(v_qr from 7);
  elsif left(v_qr, 1) = '{' then
    begin
      v_student_id := upper(regexp_replace(btrim((p_qr_value::jsonb ->> 'studentId')), '[[:space:]]', '', 'g'));
    exception when others then
      return jsonb_build_object('result', 'invalid_qr');
    end;
  elsif position('|' in v_qr) = 0 then
    v_student_id := v_qr;
  else
    return jsonb_build_object('result', 'invalid_qr');
  end if;
  if v_student_id = '' then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_student
  from public.students s
  where upper(regexp_replace(btrim(s.student_id), '[[:space:]]', '', 'g')) = v_student_id
  limit 1;
  if not found then
    return jsonb_build_object('result', 'student_not_found');
  end if;

  if p_local_time between v_event.morning_sign_in_start and v_event.morning_sign_in_end then
    v_action := 'Morning Sign In'; v_action_column := 'morning_sign_in';
  elsif p_local_time between v_event.morning_sign_out_start and v_event.morning_sign_out_end then
    v_action := 'Morning Sign Out'; v_action_column := 'morning_sign_out';
  elsif p_local_time between v_event.afternoon_sign_in_start and v_event.afternoon_sign_in_end then
    v_action := 'Afternoon Sign In'; v_action_column := 'afternoon_sign_in';
  elsif p_local_time between v_event.afternoon_sign_out_start and v_event.afternoon_sign_out_end then
    v_action := 'Afternoon Sign Out'; v_action_column := 'afternoon_sign_out';
  else
    return jsonb_build_object(
      'result', 'event_period_not_open',
      'full_name', v_student.full_name,
      'event_name', v_event.name
    );
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_event.id::text || ':' || v_student.student_id, 0));
  insert into public.event_attendance (event_id, student_id, full_name, course, year_level, section)
  values (v_event.id, v_student.student_id, v_student.full_name, v_student.course, v_student.year_level, v_student.section)
  on conflict (event_id, student_id) do nothing;
  select * into v_attendance
  from public.event_attendance
  where event_id = v_event.id and student_id = v_student.student_id
  for update;

  if (v_action_column = 'morning_sign_in' and v_attendance.morning_sign_in is not null)
    or (v_action_column = 'morning_sign_out' and v_attendance.morning_sign_out is not null)
    or (v_action_column = 'afternoon_sign_in' and v_attendance.afternoon_sign_in is not null)
    or (v_action_column = 'afternoon_sign_out' and v_attendance.afternoon_sign_out is not null) then
    return jsonb_build_object('result', 'event_action_already_recorded', 'full_name', v_student.full_name, 'action', v_action);
  end if;

  update public.event_attendance set
    full_name = v_student.full_name,
    course = v_student.course,
    year_level = v_student.year_level,
    section = v_student.section,
    morning_sign_in = case when v_action_column = 'morning_sign_in' then p_scanned_at else morning_sign_in end,
    morning_sign_out = case when v_action_column = 'morning_sign_out' then p_scanned_at else morning_sign_out end,
    afternoon_sign_in = case when v_action_column = 'afternoon_sign_in' then p_scanned_at else afternoon_sign_in end,
    afternoon_sign_out = case when v_action_column = 'afternoon_sign_out' then p_scanned_at else afternoon_sign_out end
  where id = v_attendance.id;

  if v_event.enable_fines then
    perform public.finalize_missed_event_fines(p_attendance_date, p_local_time);
  end if;
  return jsonb_build_object(
    'result', 'event_signed',
    'full_name', v_student.full_name,
    'student_id', v_student.student_id,
    'course', v_student.course,
    'year_level', v_student.year_level,
    'section', v_student.section,
    'action', v_action,
    'event_name', v_event.name,
    'enable_fines', v_event.enable_fines
  );
end;
$$;

revoke all on function public.set_active_attendance_event(uuid) from public, anon;
grant execute on function public.set_active_attendance_event(uuid) to authenticated;
revoke all on function public.finalize_missed_event_fines(date, time) from public, anon;
grant execute on function public.finalize_missed_event_fines(date, time) to authenticated;
revoke all on function public.scan_regular_four_period(text, date, time, timestamptz) from public, anon;
grant execute on function public.scan_regular_four_period(text, date, time, timestamptz) to authenticated;
revoke all on function public.scan_attendance_session(text, date, time, timestamptz) from public, anon;
grant execute on function public.scan_attendance_session(text, date, time, timestamptz) to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'events'
  ) then
    alter publication supabase_realtime add table public.events;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'event_attendance'
  ) then
    alter publication supabase_realtime add table public.event_attendance;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'fines'
  ) then
    alter publication supabase_realtime add table public.fines;
  end if;
end
$$;
