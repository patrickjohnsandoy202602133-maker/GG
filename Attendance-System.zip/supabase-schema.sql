create extension if not exists pgcrypto;

create table if not exists public.authorized_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_id text not null,
  full_name text not null,
  course text not null,
  year_level text not null check (year_level in ('1st Year', '2nd Year', '3rd Year', '4th Year')),
  section text not null check (section in ('A', 'B')),
  created_at timestamptz not null default now()
);

create unique index if not exists students_student_id_unique
  on public.students (upper(regexp_replace(btrim(student_id), '[[:space:]]', '', 'g')));

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id text not null,
  attendance_date date not null,
  time_in timestamptz,
  time_out timestamptz,
  status text not null check (status in ('Present', 'Late', 'Absent')),
  full_name text not null,
  course text not null,
  year_level text not null,
  section text not null,
  created_at timestamptz not null default now(),
  constraint attendance_student_date_unique unique (student_id, attendance_date)
);

create table if not exists public.attendance_settings (
  id integer primary key check (id = 1),
  sign_in_start time,
  sign_in_end time,
  sign_out_start time,
  sign_out_end time,
  updated_at timestamptz not null default now()
);

insert into public.attendance_settings (id)
values (1)
on conflict (id) do nothing;

alter table public.authorized_admins enable row level security;
alter table public.students enable row level security;
alter table public.attendance enable row level security;
alter table public.attendance_settings enable row level security;

drop policy if exists "Admins can view their authorization" on public.authorized_admins;
create policy "Admins can view their authorization"
  on public.authorized_admins for select to authenticated
  using (user_id = (select auth.uid()));

drop policy if exists "Authorized admins manage students" on public.students;
create policy "Authorized admins manage students"
  on public.students for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage attendance" on public.attendance;
create policy "Authorized admins manage attendance"
  on public.attendance for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

drop policy if exists "Authorized admins manage attendance settings" on public.attendance_settings;
create policy "Authorized admins manage attendance settings"
  on public.attendance_settings for all to authenticated
  using (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())))
  with check (exists (select 1 from public.authorized_admins a where a.user_id = (select auth.uid())));

grant select on public.authorized_admins to authenticated;
grant select, insert, update, delete on public.students to authenticated;
grant select, insert, update, delete on public.attendance to authenticated;
grant select, insert, update, delete on public.attendance_settings to authenticated;

create or replace function public.save_student(
  p_original_student_id text,
  p_student_id text,
  p_full_name text,
  p_course text,
  p_year_level text,
  p_section text
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    raise exception 'Administrator authorization required.';
  end if;

  if nullif(btrim(p_student_id), '') is null
    or nullif(btrim(p_full_name), '') is null
    or nullif(btrim(p_course), '') is null
    or p_year_level is null
    or p_year_level not in ('1st Year', '2nd Year', '3rd Year', '4th Year')
    or p_section is null
    or p_section not in ('A', 'B') then
    raise exception 'Student details are incomplete or invalid.';
  end if;

  if p_original_student_id is null then
    insert into public.students (student_id, full_name, course, year_level, section)
    values (btrim(p_student_id), btrim(p_full_name), btrim(p_course), p_year_level, p_section);
    return;
  end if;

  update public.students
  set student_id = btrim(p_student_id),
      full_name = btrim(p_full_name),
      course = btrim(p_course),
      year_level = p_year_level,
      section = p_section
  where student_id = p_original_student_id;
  if not found then
    raise exception 'Student not found.';
  end if;

  update public.attendance
  set student_id = btrim(p_student_id),
      full_name = btrim(p_full_name),
      course = btrim(p_course),
      year_level = p_year_level,
      section = p_section
  where student_id = p_original_student_id;
end;
$$;

create or replace function public.scan_attendance(
  p_qr_value text,
  p_attendance_date date,
  p_local_time time,
  p_scanned_at timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_student public.students%rowtype;
  v_record public.attendance%rowtype;
  v_schedule public.attendance_settings%rowtype;
  v_student_id text;
  v_qr text;
begin
  if not exists (
    select 1 from public.authorized_admins a
    where a.user_id = (select auth.uid())
  ) then
    return jsonb_build_object('result', 'auth_required');
  end if;

  if p_qr_value is null or p_attendance_date is null or p_local_time is null or p_scanned_at is null then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  v_qr := upper(regexp_replace(btrim(p_qr_value), '[[:space:]]', '', 'g'));
  if left(v_qr, 6) = 'CC101|' then
    v_student_id := substring(v_qr from 7);
  elsif left(v_qr, 1) = '{' then
    begin
      v_student_id := upper(regexp_replace(btrim((p_qr_value::jsonb ->> 'studentId')), '[[:space:]]', '', 'g'));
    exception when others then
      return jsonb_build_object('result', 'invalid_qr');
    end;
  elsif position('|' in v_qr) = 0 then
    v_student_id := v_qr;
  else
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  if v_student_id = '' then
    return jsonb_build_object('result', 'invalid_qr');
  end if;

  select * into v_student
  from public.students s
  where upper(regexp_replace(btrim(s.student_id), '[[:space:]]', '', 'g')) = v_student_id
  limit 1;
  if not found then
    return jsonb_build_object('result', 'student_not_found');
  end if;

  select * into v_schedule
  from public.attendance_settings
  where id = 1;
  if not found or v_schedule.sign_in_start is null or v_schedule.sign_in_end is null then
    return jsonb_build_object('result', 'schedule_not_configured');
  end if;

  perform pg_advisory_xact_lock(hashtextextended(v_student.student_id || ':' || p_attendance_date::text, 0));
  select * into v_record
  from public.attendance a
  where a.student_id = v_student.student_id and a.attendance_date = p_attendance_date
  for update;

  if found and v_record.time_in is not null and v_record.time_out is not null then
    return jsonb_build_object(
      'result', 'already_complete',
      'full_name', v_student.full_name,
      'student_id', v_student.student_id
    );
  end if;

  if found and v_record.time_in is not null then
    if v_schedule.sign_out_start is not null and p_local_time < v_schedule.sign_out_start then
      return jsonb_build_object('result', 'sign_out_not_open', 'full_name', v_student.full_name);
    end if;
    if v_schedule.sign_out_end is not null and p_local_time > v_schedule.sign_out_end then
      return jsonb_build_object('result', 'sign_out_closed', 'full_name', v_student.full_name);
    end if;

    update public.attendance
    set time_out = p_scanned_at,
        full_name = v_student.full_name,
        course = v_student.course,
        year_level = v_student.year_level,
        section = v_student.section
    where id = v_record.id;
    return jsonb_build_object(
      'result', 'signed_out',
      'student_id', v_student.student_id,
      'full_name', v_student.full_name,
      'course', v_student.course,
      'year_level', v_student.year_level,
      'section', v_student.section
    );
  end if;

  if p_local_time < v_schedule.sign_in_start then
    return jsonb_build_object('result', 'sign_in_not_open');
  end if;
  if p_local_time > v_schedule.sign_in_end then
    return jsonb_build_object('result', 'sign_in_closed');
  end if;

  insert into public.attendance (
    student_id, attendance_date, time_in, status, full_name, course, year_level, section
  ) values (
    v_student.student_id, p_attendance_date, p_scanned_at, 'Present',
    v_student.full_name, v_student.course, v_student.year_level, v_student.section
  )
  on conflict (student_id, attendance_date) do update
  set time_in = excluded.time_in,
      time_out = null,
      status = 'Present',
      full_name = excluded.full_name,
      course = excluded.course,
      year_level = excluded.year_level,
      section = excluded.section
  where public.attendance.time_in is null;

  return jsonb_build_object(
    'result', 'signed_in',
    'student_id', v_student.student_id,
    'full_name', v_student.full_name,
    'course', v_student.course,
    'year_level', v_student.year_level,
    'section', v_student.section
  );
end;
$$;

revoke all on function public.scan_attendance(text, date, time, timestamptz) from public, anon;
grant execute on function public.scan_attendance(text, date, time, timestamptz) to authenticated;
revoke all on function public.save_student(text, text, text, text, text, text) from public, anon;
grant execute on function public.save_student(text, text, text, text, text, text) to authenticated;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'students'
  ) then
    alter publication supabase_realtime add table public.students;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'attendance'
  ) then
    alter publication supabase_realtime add table public.attendance;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'attendance_settings'
  ) then
    alter publication supabase_realtime add table public.attendance_settings;
  end if;
end
$$;
