# Supabase setup

The app stores students, attendance, and the schedule in Supabase. It uses Supabase Auth for administrator access and Realtime for updates. No service-role key belongs in this browser app.

## 1. Create the project and schema

1. Create a Supabase project and open **SQL Editor**.
2. Run the complete contents of [`supabase-schema.sql`](./supabase-schema.sql).
3. In **Authentication → Users**, create an account for each approved administrator. Keep public sign-up disabled.
4. Copy each administrator's user UUID, then authorize them in SQL Editor:

   ```sql
   insert into public.authorized_admins (user_id)
   values ('AUTH_USER_UUID');
   ```

   Only users in `authorized_admins` can read or change student, attendance, or settings data. Revoke access by deleting that row.
5. In **Authentication → URL Configuration**, set the production static site's URL and add it as an allowed redirect URL.

## 2. Configure the browser app

In the Supabase project dashboard, open **Project Settings → API**. Copy the Project URL and the **anon / publishable** key (never the `service_role` key) into [`supabase-config.js`](./supabase-config.js):

```js
window.CC101_SUPABASE_CONFIG = {
  url: "https://YOUR_PROJECT_ID.supabase.co",
  anonKey: "YOUR_SUPABASE_ANON_KEY"
};
```

Keep the anon key's access controlled by the included Row Level Security policies. Do not put database passwords or the service-role key in this file.

## 3. Host and sign in

The app must be served from the same web host on all devices. Camera access generally requires HTTPS or localhost; opening `index.html` from a phone's file manager will not connect the devices or allow camera access. Deploy the `Attendance-System` folder to a static HTTPS host, or use a local development server on the computer and expose it securely to the phone.

Sign in on both the administrator computer and scanning phone with an approved administrator account. Configure the schedule in Settings. All school devices should use the school's local time zone because scans are checked against the scanning device's local date and time; `time_in` and `time_out` are stored as timezone-aware timestamps.

## Existing local-only data

Data previously saved in this browser's localStorage is not used as live app data. If the cloud project has no students, the dashboard offers **Import previous data** when this browser contains the old app state. The import skips existing cloud rows, can be safely retried if interrupted, and does not delete the old local copy.

## Database and security notes

- `students.student_id` is unique case-insensitively and remains the QR identifier.
- `attendance` keeps a student-information snapshot so deleting a student does not erase historical attendance.
- The `scan_attendance` database function performs check-in/out, enforces the saved schedule, and prevents duplicate daily rows within one transaction.
- Student additions and edits use the `save_student` database function so Student ID changes and historical attendance snapshots update atomically.
- Anonymous roles have no student/attendance/settings table access and cannot call the scanner function. The phone must use an authorized admin sign-in.
- RLS policies grant access only to UUIDs explicitly listed in `authorized_admins`.
- Realtime publication is enabled for students, attendance, and attendance settings by the SQL script.
